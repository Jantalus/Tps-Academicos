import matplotlib.pyplot as plt

labels = ['Acceso a memoria', 'Procesamiento', 'Escritura']#nombre respectivo de cada porcion/color
sizes = [33.3, 33.3, 33.3]
colors = ['red', 'green', 'blue']
patches, texts = plt.pie(sizes, colors=colors, shadow=True, startangle=90, labels = ['33,3%', '33,3%', "33,3%"])
plt.legend(patches, labels, loc="best")                                        # etiqueta para cada porcion(opcional)
plt.axis('equal')
plt.tight_layout()
plt.show()