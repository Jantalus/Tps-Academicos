import os
import subprocess
import pathlib
import fileinput
import datetime

#Obtengo el instante actual para ponerle un timestamp a los datos de salida
instante = (datetime.datetime.now())
#Le doy formato al instante
ahora = instante.strftime("%d-%m-%Y %Hh %Mm %Ss")
path_relativo_ejec = "./../src/build/tp2"
path_relativo_entrada = "../src/img/basico"
path_relativo_salida = "../src/img/basico"
makefiles = ["../src/Makefile","../src/filters/Makefile","../src/helper/Makefile"]
nombre_datos_salida = "(" + ahora + ") PRELIMINAR"
#entradas = ["basico_color","applelogo","basico_coupdeventcopy","basico_fractal","basico_hawaii","basico_molino","basico_ruidoblanco"]
entradas = ["basico_color", "basico_downtown","basico_fractal","basico_peasanthouse","basico_ruidoblanco"]

dimensiones = {
	"basico_color" : 1024*768,
	"basico_downtown" : 1920*1248,
	"basico_fractal" : 1200*2000,
	"basico_peasanthouse" : 896*753,
	"basico_ruidoblanco" : 800*960
}
filtro = ["Rombos","Nivel","Bordes"]
implementacion = ["asm","O0","O1","O2","O3"]
parametro_i = {
	"asm" : "asm",
	"O0" : "c",
	"O1" : "c",
	"O2" : "c",
	"O3" : "c"
}
busco = {
	"asm" : "-O0",
	"O0" : "-O0",
	"O1" : "-O1",
	"O2" : "-O2",
	"O3" : "-O3"
}
cambio = {
	"asm" : "-O0",
	"O0" : "-O1",
	"O1" : "-O2",
	"O2" : "-O3",
	"O3" : "-O0"
}
cant_iteraciones = 10
nivel = 1

p = pathlib.Path("(" + ahora + ") PRELIMINAR")
p.mkdir(parents=True, exist_ok=True)


for archivo in entradas:
	print(nombre_datos_salida + " " + archivo + ".txt")
	print(archivo.upper())
	for fil in filtro:
		print("\t" + fil.upper())
		for imp in implementacion:
			subprocess.call(["make","-C","../src/","clean"])
			subprocess.call(["make", "-C", "../src/"])
			datosDump = open(str(p) + "/" + archivo + fil.upper() + imp.upper() + ".txt","w")
			datosDump.write(str(dimensiones.get(archivo))+"\n")
			print("\t\t" + imp.upper())
			if (imp=="Nivel"):
				dump = subprocess.check_output([path_relativo_ejec,"-t",str(cant_iteraciones),"-i",parametro_i.get(imp),"-o",path_relativo_salida,fil,str(os.path.join(path_relativo_entrada,archivo)) + ".bmp",str(nivel)])
			else:
				dump = subprocess.check_output([path_relativo_ejec,"-t",str(cant_iteraciones),"-i",parametro_i.get(imp),"-o",path_relativo_salida,fil,str(os.path.join(path_relativo_entrada,archivo)) + ".bmp"])
			datosDump.write(dump.decode("utf-8"))
			datosDump.close()
			for make in makefiles:
				for line in fileinput.input(make,inplace=True):
					print(line.replace(busco.get(imp),cambio.get(imp)).strip("\n"))
