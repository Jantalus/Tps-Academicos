import numpy as np
import glob
import sys
import matplotlib.pyplot as plt
import matplotlib as mpl

if len(sys.argv)!=2:
  print("Este script debe recibir como único parámetro la carpeta que contiene los datos producidos por preliminar.py\n")
  sys.exit()

def autolabel(rects):
    """Attach a text label above each bar in *rects*, displaying its height."""
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{0:.2f}'.format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom')

imagenes = ["basico_color", "basico_downtown","basico_fractal","basico_peasanthouse","basico_ruidoblanco"]
filtros = ["Rombos","Nivel","Bordes"]

width = 0.35

carpeta = sys.argv[1]
archivos_ASM = []
archivos_O0 = []
archivos_O1 = []
archivos_O2 = []
archivos_O3 = []

for name in glob.glob(carpeta + "/*O0.txt"):
  archivos_ASM.append(str(name)[:-6] + "ASM.txt")
  archivos_O0.append(str(name))
  archivos_O1.append(str(name)[:-5] + "1.txt")
  archivos_O2.append(str(name)[:-5] + "2.txt")
  archivos_O3.append(str(name)[:-5] + "3.txt")

for imagen in imagenes:
  dumpASM = []
  dumpO0 = []
  dumpO1 = []
  dumpO2 = []
  dumpO3 = []
  media_ASM = []
  media_O0 = []
  media_O1 = []
  media_O2 = []
  media_O3 = []
  std_ASM = []
  std_O0 = []
  std_O1 = []
  std_O2 = []
  std_O3 = []
  #Traigo subselección de archivos de cada implementación, filtrándolos para quedarme solamente con los correspondientes a la imagen actual.
  subselec_ASM = [x for x in archivos_ASM if imagen in x]
  subselec_O0 = [x for x in archivos_O0 if imagen in x]
  subselec_O1 = [x for x in archivos_O1 if imagen in x]
  subselec_O2 = [x for x in archivos_O2 if imagen in x]
  subselec_O3 = [x for x in archivos_O3 if imagen in x]
  
  obtenerDimensiones = open(subselec_ASM[0],'r')
  pixeles = int(obtenerDimensiones.readline().strip().strip('\u202c'))
  obtenerDimensiones.close()
  

  for fil in filtros:
    print(subselec_ASM)
    archivoActual_ASM = open(next(x for x in subselec_ASM if fil.upper() in x),'r')
    archivoActual_O0 = open(next(x for x in subselec_O0 if fil.upper() in x),'r')
    archivoActual_O1 = open(next(x for x in subselec_O1 if fil.upper() in x),'r')
    archivoActual_O2 = open(next(x for x in subselec_O2 if fil.upper() in x),'r')
    archivoActual_O3 = open(next(x for x in subselec_O3 if fil.upper() in x),'r')

    for renglon in archivoActual_ASM.readlines():
        dumpASM.append(int(renglon.strip())/pixeles)
    
    archivoActual_ASM.close()
    
    for renglon in archivoActual_O0.readlines():
      dumpO0.append(int(renglon.strip())/pixeles)
    
    archivoActual_O0.close()
    
    for renglon in archivoActual_O1.readlines():
      dumpO1.append(int(renglon.strip())/pixeles)
    
    archivoActual_O1.close()
    
    for renglon in archivoActual_O2.readlines():
      dumpO2.append(int(renglon.strip())/pixeles)
    
    archivoActual_O2.close()
    
    for renglon in archivoActual_O3.readlines():
      dumpO3.append(int(renglon.strip())/pixeles)
    
    archivoActual_O3.close()
    
    prestd_ASM = np.std(dumpASM)
    prestd_O0 = np.std(dumpO0)
    prestd_O1 = np.std(dumpO1)
    prestd_O2 = np.std(dumpO2)
    prestd_O3 = np.std(dumpO3)
    premedia_ASM = np.mean(dumpASM)
    premedia_O0 = np.mean(dumpO0)
    premedia_O1 = np.mean(dumpO1)
    premedia_O2 = np.mean(dumpO2)
    premedia_O3 = np.mean(dumpO3)
    filtroASM = [x for x in dumpASM if (premedia_ASM - prestd_ASM < x < premedia_ASM + prestd_ASM)]
    filtroO0 = [x for x in dumpO0 if (premedia_O0 - prestd_O0 < x < premedia_O0 + prestd_O0)]
    filtroO1 = [x for x in dumpO1 if (premedia_O1 - prestd_O1 < x < premedia_O1 + prestd_O1)]
    filtroO2 = [x for x in dumpO2 if (premedia_O2 - prestd_O2 < x < premedia_O2 + prestd_O2)]
    filtroO3 = [x for x in dumpO3 if (premedia_O3 - prestd_O3 < x < premedia_O3 + prestd_O3)]
    std_ASM.append(np.std(filtroASM))
    std_O0.append(np.std(filtroO0))
    std_O1.append(np.std(filtroO1))
    std_O2.append(np.std(filtroO2))
    std_O3.append(np.std(filtroO3))
    media_ASM.append(np.mean(filtroASM))
    media_O0.append(np.mean(filtroO0))
    media_O1.append(np.mean(filtroO1))
    media_O2.append(np.mean(filtroO2))
    media_O3.append(np.mean(filtroO3))


  print("media_ASM:\n")
  print(media_ASM)
  print("media_O0:\n")
  print(media_O0)
  print("media_O1:\n")
  print(media_O1)
  print("media_O2:\n")
  print(media_O2)
  print("media_O3:\n")
  print(media_O3)

  labels = ['Rombos','Nivel','Bordes']
  x_pos = 2*np.arange(len(labels))
  medias = [media_ASM, media_O0, media_O1, media_O2, media_O3]
  errores = [std_ASM, std_O0, std_O1, std_O2, std_O3]
  fig, ax = plt.subplots(figsize = [10, 4.8])
  barASM = ax.bar(x_pos - 2*width, media_ASM, width, yerr=std_ASM, label='ASM',capsize=10)
  barO3 = ax.bar(x_pos - width, media_O3, width, yerr=std_O0,label='C (-O3)',capsize=10)
  barO2 = ax.bar(x_pos , media_O2, width, yerr=std_O1,label='C (-O2)',capsize=10)
  barO1 = ax.bar(x_pos + width, media_O1, width, yerr=std_O2,label='C (-O1)',capsize=10)
  barO0 = ax.bar(x_pos + 2*width, media_O0, width, yerr=std_O3,label='C (-O0)',capsize=10)

  autolabel(barASM)
  autolabel(barO0)
  autolabel(barO1)
  autolabel(barO2)
  autolabel(barO3)

  ax.set_ylabel('Ciclos de reloj/píxel')
  ax.set_title('Eficiencia temporal - "' + imagen + '.bmp"')
  ax.set_xticks(x_pos)
  ax.set_xticklabels(labels)
  ax.legend()
  fig.tight_layout()
  plt.show()
