import numpy as np
import matplotlib.pyplot as plt


N = 4
branchHit = (20000000, 35000000,320000000,23000000)
branchMisses = (250000000, 320000000,120000000,120000000) #que las mediciones no se pasen del limite de yticks
nHits = (2, 3, 4, 1)
nMisses = (3, 5, 2, 3)
ind = np.arange(N)    # the x locations for the groups
width = 0.35       # the width of the bars: can also be len(x) sequence

p1 = plt.bar(ind, branchHit, width, )
p2 = plt.bar(ind, branchMisses, width, bottom=branchHit)

plt.ylabel('Escala en 100millones')
plt.title('Branch misspredictions segun archivo de entrada (Nivel C)')
plt.xticks(ind, ('blanco.bmp', 'negro.bmp', 'checkers.bmp', 'ruido.bmp'))
plt.yticks(np.arange(0, 400000000, 50000000))
plt.legend((p1[0], p2[0]), ('Branch hit', 'Branch miss'))

plt.show()