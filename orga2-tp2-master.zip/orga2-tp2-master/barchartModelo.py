import numpy as np
import matplotlib.pyplot as plt

# data to plot
n_groups = 2 # Cantidad de imagenes a comparar 

#1 es 100%

asm = (1,2)#(medicionImagen1,medicionImagen2.., medicionImagenNGROUPS) 

c =(3,4) #(medicionImagen1,medicionImagen2.., medicionImagenNGROUPS)


#metodo3 = (#lo mismmo)

# create plot
fig, ax = plt.subplots()
index = np.arange(n_groups)
bar_width = 0.2 
opacity = 0.8

rects1 = plt.bar(index, asm, bar_width,
alpha=opacity,
color='r',
label='ASM')

rects2 = plt.bar(index + bar_width, c, bar_width,
alpha=opacity,
color='g',
label='C')

#rects3 = plt.bar(index + 2*bar_width, wp, bar_width,
#alpha=opacity,
#color='b',
#label='label3')
	
plt.xlabel('Nombre eje x')
plt.ylabel('Nombre eje y')
plt.title('Titulo del grafico')
plt.yticks(np.arange(0,7,0.5), ('0%', '50%', '100%', '150%', '200%', '250%'))
plt.xticks(index + bar_width/2, ('imagen 1', 'imagen 2'))                               #// tambien si le sumas a index podes poner 
plt.legend()    # tantas etiquetas como n_groups(no es obligatorio)        // la etiqueta del tick +- lo que quieras

plt.tight_layout()
plt.show()