#include "funcs.h"

matriz construirPoli(vector Xs, unsigned int n){
	matriz A(Xs.size(),n+1);
	//////////////////////Ver si es posible usar column-wise power.///////////////////////////////////////
	for (unsigned int col = 0; col < n+1 ; ++col){
		for (unsigned int fila = 0; fila < Xs.size() ; ++fila)
		{
			A(fila, col) = pow(Xs(fila),n-col);
		}
	}
	return A;
}

matriz construirMulti(vector Xs, int n, vector Ks){
	matriz A(Xs.size(), n+1 + Ks.size()*2);
	//Primero armo la parte polinomica
	for (int col = 0; col < n+1 ; ++col){
		for (int fila = 0; fila < Xs.size() ; ++fila)
		{
			A(fila, col) = pow(Xs(fila),n-col);
		}
	}
	//Segundo armo los senos
	for (int col = n+1; col < n+1 + Ks.size(); ++col){
		for (int fila = 0; fila < Xs.size(); ++fila){
			double arg = Xs(fila)*2*M_PI / Ks(col - (n+1));
			A(fila, col) = sin(arg);
		}
	}
	//Tercero armo los cosenos
	for (int col = n+1+Ks.size(); col < n+1+Ks.size()*2; ++col){
		for (int fila = 0; fila < Xs.size(); ++fila){
			double arg = Xs(fila)*2*M_PI / Ks(col - (n+1 + Ks.size()));
			A(fila, col) = cos(arg);
		}
	}
	return A;
}

vector resolver(matriz A, vector b){
	return A.bdcSvd(ComputeThinU | ComputeThinV).solve(b);
}

double RMSE(matriz A, vector sol, vector b){
	vector bAprox = A*sol;
	vector error = bAprox-b;
	double rmse = sqrt(pow(error.norm(),2)/b.size());
	return rmse;
}

double NRMSE(matriz A, vector sol, vector b){
	double rmse = RMSE(A,sol,b);
	double ymax = b.maxCoeff();
	double ymin = b.minCoeff();
	double res = rmse/(ymax-ymin);
	return res;
}