#include <Eigen/Dense>

using namespace Eigen;

//Vamos a llamar 'matrix' a una Matriz de floats de dimensiones dinámicas.
typedef MatrixXd	matriz;
//Vamos a llamar 'vector' a una Matriz de floats de dimensión 1 x D, con D un valor dinámico.
typedef VectorXd	vector;