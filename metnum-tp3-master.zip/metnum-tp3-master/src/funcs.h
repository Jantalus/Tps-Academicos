#include "typedef.cpp"	/* matriz,vector */
#include <math.h>		/* sin,pow */

matriz construirMulti(vector Xs, int n, vector Ks);		//Esta función no se usa
matriz construirPoli(vector Xs, unsigned int n);		//Esta función no se usa
vector resolver(matriz A, vector b);					//Dada una matriz A (mxn) y un vector columna b (n), resuelve el problema de cuadrados mínimos lineales asociado al sistema de ecuaciones Ax=b.
double RMSE(matriz A, vector sol, vector b);			//Dada una matriz A (mxn), un vector columna sol (n) y un vector columna b (m), calcular la raíz del error cuadrático medio cometido por el modelo de función elegido, con los coeficientes indicados por el vector sol.
double NRMSE(matriz A, vector sol, vector b);			//Dada una matriz A (mxn), un vector columna sol (n) y un vector columna b (m), calcular la raíz del error cuadrático medio normalizado (es decir, dividido por ymax-ymin) cometido por el modelo de función elegido, con los coeficientes indicados por el vector sol.
