#include <pybind11/pybind11.h>
#include <pybind11/eigen.h>
#include "funcs.h"

namespace py=pybind11;

PYBIND11_MODULE(CML, m) {
    m.def(
        "resolver", &resolver,
        "Dada una matriz A y un vector b de dimensiones compatibles, calcula la solución de cuadrados mínimos lineales para el sistema Ax=b.",
        py::arg("A"),
        py::arg("b")
    );
    m.def(
        "RMSE", &RMSE,
        "Dada una matriz A de dimensiones nxm, un vector 'sol' de dimensión m y un vector 'b' de dimensión n, calcula la raíz del error cuadrático medio.",
        py::arg("A"),
        py::arg("sol"),
        py::arg("b")
    );
    m.def(
        "NRMSE", &NRMSE,
        "Dada una matriz A de dimensiones nxm, un vector 'sol' de dimensión m y un vector 'b' de dimensión n, calcula la raíz del error cuadrático medio normalizado según (ymax-ymin).",
        py::arg("A"),
        py::arg("sol"),
        py::arg("b")
    );
}
