#include "funcs.h"
#include <iostream>		/* cout */

int main(){
	std::cout << "Probemos CML: tenemos 5 puntos correspondientes a la ecuación cúbica -4x^(3)+3x^(2)+25x+6. Hagamos CML con un modelo de función de la forma f(x) = ax^3 + bx^2 + cx + d." << std::endl;
 	std::cout << "Los puntos son: (-2,0), (-0.25,0), (-1.2148663192706,-12.7718718141449) (0,6), (3,0)." << std::endl;
 	vector Xs(5);
 	Xs << -2.0,-0.25,-1.2148663192706,0.0,3.0;
 	vector Ys(5);
 	Ys << 0.0,0.0,-12.7718718141449,6.0,0.0;
 	
  	vector XsMulti(5);
 	XsMulti << -2.6031152441406,-2.0,0.0,2.0,2.6031152482493;
 	vector YsMulti(5);
 	YsMulti << -3.5511019658224,-2.0,0.0,2.0,3.5511019658224;
 	vector Ks(1);
 	Ks << 2;
 	auto A = construirMulti(XsMulti,1,Ks);
 	auto sol = resolver(A,YsMulti);
 	std::cout << "La solucion de CML es: " << std::endl << sol.transpose() << std::endl;
 	std::cout << "RMSE: " << std::endl << RMSE(A,sol,YsMulti) << std::endl; 	
 	/*
 	matriz A(5, 4);
 	A <<  	pow(-2.0,3), pow(-2.0,2), -2, 1,
 			pow(-0.25,3), pow(-0.25,2), -0.25, 1,
 			pow(-1.2148663192706,3), pow(-1.2148663192706,2),-1.2148663192706,1,
 			0,0,0,1,
 			pow(3,3), pow(3,2), 3,1;
 	std::cout << "Matriz A:\n" << A << std::endl;
 	vector b(5);
 	b << 0.0,0.0,-12.7718718141449,6.0,0.0;
 	std::cout << "Vector b:\n" << b << std::endl;
 	std::cout << "La solución de CML es:\n"
        << resolver(A,b) << std::endl;
    */
    return 0;
}