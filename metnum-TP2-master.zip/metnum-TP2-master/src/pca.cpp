#include <iostream>
#include "pca.h"
#include "eigen.h"
/*
////////////ESTO ES PARA PODER PRINTEAR COSAS AL NOTEBOOK//////////////////
#include <pybind11/embed.h>
#include <pybind11/pybind11.h>

using namespace std;
namespace py = pybind11;
///////////////////////////////////////////////////////////////////////////
*/
using namespace std;

PCA::PCA(unsigned int n_components):_n_components(n_components){}

void PCA::fit(Matrix X){
	//cout << "Matriz de entrada es de " << X.rows() << "x" << X.cols() << endl;
	Matrix muestra(X);
	//cout << "Matriz de entrada:" << endl << muestra << endl; // Asigno la muestra de vectores al campo correspondiente de la clase
	Vector u = muestra.colwise().sum().transpose();
	//cout << "Vector suma: " << endl << u.transpose() << endl;
	u /= muestra.rows();		                            // "u" es el vector promedio
	//cout << "Vector promedio: " << endl << u.transpose() << endl;
	Matrix M = muestra.rowwise() - u.transpose();			// Resto "u" a cada fila  de la matriz muestra.
	//cout << "Matriz - u:" << endl << M << endl;				// Asigno la muestra de vectores al campo correspondiente de la clase
	Matrix covar = (M.transpose() * M);	                    // "covar" es la matriz de covarianza asociada a la muestra
	//cout << "n-1 = " << M.rows()-1 << endl;
	covar /= (M.rows()-1);
	//cout << "Matriz de covarianza:" << endl << covar << endl;	// Asigno la muestra de vectores al campo correspondiente de la clase
	pair<Vector, Matrix> eigenpar = get_first_eigenvalues(covar, _n_components);
    // La matriz V tiene como columnas los autovectores de la matriz de covarianza
    // Asigno la muestra de vectores al campo correspondiente de la clase
	//cout << "Base de autovectores de la matriz de covarianza:" << endl << V << endl;
    // Asigno la muestra de vectores al campo correspondiente de la clase
	//cout << "Autovalores de la matriz de covarianza:" << endl << eigenpar.first << endl;
	_muestra = eigenpar.second;
	return;
}


MatrixXd PCA::transform(SparseMatrix X){
	Matrix A(X);
	MatrixXd res = (A * _muestra).leftCols(_n_components);
	return res;
}

void PCA::nuevoAlfa(unsigned int alfa) {
    _n_components = alfa;
}
