#pragma once

#include "types.h"
#include <vector>

class KNNClassifier {
public:
    KNNClassifier(unsigned int n_neighbors);

    void fit(SparseMatrix X, Matrix y);

    Matrix getX();
    Matrix getY();

    Vector predict(SparseMatrix X);
private:
    unsigned int _neighbors;
    Matrix _Xtrain;
    Matrix _Ytrain;
};

double norma_euclidea(Vector v, Vector u);
double norma_manhattan(Vector v, Vector u);
double norma_hamming(Vector v, Vector u);
double norma_chebyshev(Vector v, Vector u);

template <typename T>
void printVector_C(std::vector<T> v);

template <typename T>
void printArray_C(T* v, unsigned int size);

void printMatriz_C(Matrix M);
void printSparseMatrix_C(SparseMatrix M);
void printEigenVector_C(Vector v);