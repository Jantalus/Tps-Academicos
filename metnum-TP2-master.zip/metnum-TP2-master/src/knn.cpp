#define Euclidea 0
#define Manhattan 1
#define Hamming 2
#define Chebyshev 3

#include <algorithm>
//#include <chrono>
#include <iostream>
#include "knn.h"
/*
////////////ESTO ES PARA PODER PRINTEAR COSAS AL NOTEBOOK//////////////////
#include <pybind11/embed.h>
#include <pybind11/pybind11.h>

using namespace std;
namespace py = pybind11;
///////////////////////////////////////////////////////////////////////////
*/
using namespace std;
/*
void printMatriz_py(Matrix M){
    for(unsigned int i=0;i<M.cols();i++){
        for(unsigned int j=0;j<M.rows();j++){
            py::print(M(j,i));
        }
    }
    py::print("\n");
    return;
}

template <typename T>
void printVector_py(vector<T> v){
    for(unsigned int i=0;i<v.size();i++){
        py::print(v[i]);
    }
    py::print("\n");
    return;
}
*/

void printMatriz_C(Matrix M){
    for(unsigned int i=0;i<M.rows();i++){
        for(unsigned int j=0;j<M.cols();j++){
            cout << (M(i,j)) << ", ";
        }
        cout << endl;
    }
    cout << endl;
    return;
}

void printSparseMatrix_C(SparseMatrix M){
    for(unsigned int i=0;i<M.rows();i++){
        for(unsigned int j=0;j<M.cols();j++){
            cout << (M.coeff(i,j)) << ", ";
        }
        cout << endl;
    }
    cout << endl;
    return;
}

void printEigenVector_C(Vector v){
    cout << "[";
    for(unsigned int i=0;i<v.size()-1;i++){
        cout << v(i) << ", ";
    }
    cout << v(v.size()-1);
    cout << "]" << endl << endl;
    return;
}

template <typename T>
void printVector_C(vector<T> v){
    cout << "[";
    for(unsigned int i=0;i<v.size()-1;i++){
        cout << v[i] << ", ";
    }
    cout << v[v.size()-1];
    cout << "]" << endl << endl;
    return;
}

template <typename T>
void printArray_C(T* v, unsigned int size){
    cout << "[";
    for(unsigned int i=0;i<size-1;i++){
        cout << v[i] << ", ";
    }
    cout << v[size-1];
    cout << "]" << endl << endl;
    return;
}

double (*metrica[]) (Vector v, Vector u) = {norma_euclidea,norma_manhattan,norma_hamming,norma_chebyshev};


double moda(double* candidatos, unsigned int size, pair<double,int>* dist){
    bool todosIguales = (dist[0].first==dist[size-1].first);
    float suma=0.0;
    for(unsigned int i=0; i<size;i++){
        //cout << i+1 << "° candidato: "<<candidatos[i] << endl;
        if(candidatos[i]>0.5){
            suma+=(todosIguales ? 1 : (dist[size-1].first-dist[i].first)/(dist[size-1].first-dist[0].first));
            //cout << "Incremento contador" << endl;
        }
        else{
            suma-=(todosIguales ? 1 : (dist[size-1].first-dist[i].first)/(dist[size-1].first-dist[0].first));
            //cout << "Decremento contador" << endl;
        }
    }
    ///////////////////////////////////////////////////////////////////////
    //py::print("Resultado de la votación: ", (contador>0 ? 1.0 : 0.0), "\n");
    //py::print("\n");
    ///////////////////////////////////////////////////////////////////////
    //cout << "Valor final del contador: " << contador << endl;
    return (suma>0 ? 1.0 : 0.0);
}

/*
double moda(double* candidatos, unsigned int size){
    int contador=0;
    for(unsigned int i=0; i<size;i++){
        //cout << i+1 << "° candidato: "<<candidatos[i] << endl;
        if(candidatos[i]>0.5){
            contador++;
            //cout << "Incremento contador" << endl;
        }
        else{
            contador--;
            //cout << "Decremento contador" << endl;
        }
    }
    ///////////////////////////////////////////////////////////////////////
    //py::print("Resultado de la votación: ", (contador>0 ? 1.0 : 0.0), "\n");
    //py::print("\n");
    ///////////////////////////////////////////////////////////////////////
    //cout << "Valor final del contador: " << contador << endl;
    return (contador>0 ? 1.0 : 0.0);
}
*/
/*
double moda(double* candidatos, unsigned int size){
    double contadorPos=0;
    double contadorNeg=0;
    for(unsigned int i=0; i<size;i++){
        //cout << i+1 << "° candidato: "<<candidatos[i] << endl;
        if(candidatos[i]>0.5){
            contadorPos += 1/(i+1);
            //cout << "Incremento contador" << endl;
        }
        else{
            contadorNeg+=1/(i+1);
            //cout << "Decremento contador" << endl;
        }
    }
    ///////////////////////////////////////////////////////////////////////
    //py::print("Resultado de la votación: ", (contador>0 ? 1.0 : 0.0), "\n");
    //py::print("\n");
    ///////////////////////////////////////////////////////////////////////
    //cout << "Valor final del contador: " << contador << endl;
    return (contadorPos>contadorNeg ? 1.0 : 0.0);
}
*/

double norma_euclidea(Vector v, Vector u){
	double dist = (v-u).norm();
	return dist;
}

double norma_manhattan(Vector v, Vector u){
	float blah = (v-u).cwiseAbs().sum();
	return double(blah);
}

double norma_hamming(Vector v, Vector u){
	auto temp = v-u;
	double dist = 0.0;
	for(int i=0; i<v.size();i++){
		if(temp(i)!=0) dist+=1.0;
	}
	return dist;
}

double norma_chebyshev(Vector v, Vector u){
	float dist = (v-u).cwiseAbs().maxCoeff();
	return double(dist);
}

KNNClassifier::KNNClassifier(unsigned int n_neighbors): _neighbors(n_neighbors){}

void KNNClassifier::fit(SparseMatrix X, Matrix y){
	_Xtrain = Matrix(X);
	_Ytrain = y;
}

Matrix KNNClassifier::getX(){
    return _Xtrain;
}

Matrix KNNClassifier::getY(){
    return _Ytrain;
}

Vector KNNClassifier::predict(SparseMatrix X){
    auto A = Matrix(X);
    auto ret = Vector(A.rows()); // defino ret aca
    double candidatos[_neighbors];
	pair<double,int> distancias[_Xtrain.rows()];
	for(unsigned int i=0;i<A.rows();i++){
        /////////////////////////////////////////
        //py::print("Vector:");
        //printMatriz_py(A.row(i));
        //py::print("\n");
        /////////////////////////////////////////
        //cout << i+1 << "° vector fila de la matriz de entrada:" << endl;
        //printMatriz_C(A.row(i));
        for (unsigned int j=0;j<_Xtrain.rows();j++){
            distancias[j]=make_pair((*metrica[Manhattan])(_Xtrain.row(j), A.row(i)), j);
        }
        sort(distancias, distancias+_Xtrain.rows()); // por default, c++ sortea según la primer coordenada
        //cout << _neighbors << " más cercanos al vector actual: " << endl;
        for (unsigned int k=0;k<_neighbors;k++) {
            //printMatriz_C(_Xtrain.row(distancias[k].second));
            //cout << "(etiqueta asociada: " << _Ytrain(distancias[k].second) << ")" << endl;
            candidatos[k]=_Ytrain(distancias[k].second);
        }
        //cout << "k = " << _neighbors << ". Candidatos para el " << i+1 << "° vector fila de la matriz de entrada:" << endl;
        //printArray_C(candidatos,_neighbors);
        ret(i) = moda(candidatos,_neighbors,distancias);
        //cout << "Predicción para el " << i+1 << "° vector fila de la matriz de entrada:" << endl << ret(i) << endl << endl;
    }
    //py::print("\n");
    //py::print("Predicciones: ");
    //printMatriz_py(ret);
    //cout << "Vector de predicciones: " << endl;
    //printEigenVector_C(ret);
    return ret;
}
