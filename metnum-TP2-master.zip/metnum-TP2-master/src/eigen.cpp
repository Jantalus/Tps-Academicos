#include <algorithm>
#include <chrono>
#include <iostream>
#include "eigen.h"

using namespace std;


pair<double, Vector> rayleigh_quotient(const Matrix& X, unsigned num_iter, double eps){
    Vector v = Vector::Random(X.cols());
    v/=v.norm();
    Vector v_new = v;
    double eigenvalue = v.transpose() * X * v;
    cout << "Epsilon: " << eps << endl;
    unsigned int i = 0;
    while((i==0) ||(i<num_iter && (X*v_new-eigenvalue*v_new).norm()>eps)){ //hace por lo menos una iteracion. y frena segun el criterio de parada
        v = v_new;
        v_new = X*v;
        v_new/= v_new.norm();
        eigenvalue = v.transpose() * X * v;
        i++;
    }
    cout << "Iteraciones realizadas: " << i << endl;
    return make_pair(eigenvalue, v_new);
}


pair<double, Vector> power_iteration(const Matrix& X, unsigned num_iter, double eps){
    return rayleigh_quotient(X,num_iter,eps);
}

pair<Vector, Matrix> get_first_eigenvalues(const Matrix& X, unsigned num, unsigned num_iter, double epsilon){
    Matrix A(X);
    Vector eigenvalues(num);
    Matrix eigenvectors(X.cols(),num);
    pair<double,Vector> autopar;
    for(unsigned int i = 0; i<num;i++){
        cout << "Calculando " << i << "° autopar..." << endl;
        autopar = power_iteration(A,num_iter,epsilon);
        cout << "Se calculó el " << i << "° autopar:" << endl;
        cout << "Calculando nueva matriz..." << endl;
        A -= autopar.first * autopar.second * autopar.second.transpose();
        cout << "Calculada la nueva matriz" << endl;
        cout << "Asignando nuevo autopar al par de retorno..." << endl;
        eigenvalues(i) = autopar.first;
        eigenvectors.col(i) = autopar.second;
        cout << "Asignado." << endl;
        //cout << i+1 << "° autovalor: " << autopar.first << endl;
        //cout << i+1 << "° autovector: " << endl << autopar.second << endl << endl;
    }
    return make_pair(eigenvalues, eigenvectors);
}

