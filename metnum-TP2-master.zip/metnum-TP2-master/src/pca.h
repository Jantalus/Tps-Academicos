#pragma once
#include "types.h"

class PCA {
public:
    PCA(unsigned int n_components);

    void fit(Matrix X);

    Eigen::MatrixXd transform(SparseMatrix X);

    void nuevoAlfa(unsigned int alfa);
private:
	Matrix _muestra;
	unsigned int _n_components;
};
