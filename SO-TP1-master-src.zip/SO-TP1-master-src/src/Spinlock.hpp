#ifndef SPIN_LOCK_HPP
#define SPIN_LOCK_HPP

#include <atomic>

class Spinlock {
public:
    void acquire() {
        while(_flag.test_and_set(std::memory_order_acquire)){}
    }
    void release() {
        _flag.clear(std::memory_order_release);
    }
private:
    std::atomic_flag _flag = ATOMIC_FLAG_INIT;
};

#endif  /* SPIN_LOCK_HPP */