#ifndef LISTA_ATOMICA_HPP
#define LISTA_ATOMICA_HPP

#define LISTA_SPINLOCK  1
#define LISTA_MUTEX     2
#define LISTA_SEMAFORO  3

/* Compilación condicional: con el siguiente #define se elige la implementación de ListaAtomica a utilizar */
#define LISTA_IMP LISTA_SPINLOCK
/*****************************************************************************************************************/

#if LISTA_IMP == LISTA_SPINLOCK

#include <atomic>

template<typename T>
class ListaAtomica {
 private:
    struct Nodo {
        Nodo(const T &val) : _valor(val), _siguiente(nullptr) {}

        T _valor;
        Nodo *_siguiente;
    };

    std::atomic<Nodo *> _cabeza;

 public:
    ListaAtomica() : _cabeza(nullptr) {}

    ~ListaAtomica() {
        Nodo *n, *t;
        n = _cabeza.load();
        while (n) {
            t = n;
            n = n->_siguiente;
            delete t;
        }
    }

    void insertar(const T &valor) {
        //Creo el nodo nuevo
        Nodo* nuevo = new Nodo(valor);
        
        //Este va a ser mi 'expected' para el valor de _cabeza
        Nodo* primero = _cabeza;
        nuevo->_siguiente = primero;
        
        //Si _cabeza==primero es porque nadie lo cambió en el interín, así que gané.
        //Si _cabeza!=primero es porque alguien ya insertó.
        //En ese caso debo actualizar mi valor 'expected'. Esto lo hace automáticamente compare_exchange_weak.
        while(!_cabeza.compare_exchange_weak(primero, nuevo)){
                nuevo->_siguiente = primero;
        }
        
        //Si llegué acá es porque '_cabeza' era igual a a mi predicción, 'primero'.
        //Pero además, si llegué acá sé que atómicamente asigné _cabeza=nuevo.
        //Luego, 'nuevo' ahora es el primero de la lista. ¿Cuál es su siguiente? Su siguiente es 'primero',
        //porque ese es el valor que tenía '_cabeza' inmediatamente antes de que yo lo intercambiara.
    }

    T &cabeza() const {
        return _cabeza.load()->_valor;
    }

    T &iesimo(unsigned int i) const {
        Nodo *n = _cabeza.load();
        for (unsigned int j = 0; j < i; j++) {
            n = n->_siguiente;
        }
        return n->_valor;
    }

    unsigned int longitud() const {
        Nodo *n = _cabeza.load();
        unsigned int cant = 0;
        while (n != nullptr) {
            cant++;
            n = n->_siguiente;
        }
        return cant;
    }


    class Iterador {
     private:
        ListaAtomica *_lista;

        typename ListaAtomica::Nodo *_nodo_sig;

        Iterador(ListaAtomica<T> *lista, typename ListaAtomica<T>::Nodo *sig)
            : _lista(lista), _nodo_sig(sig) {}

        friend typename ListaAtomica<T>::Iterador ListaAtomica<T>::crearIt();

     public:
        Iterador() : _lista(nullptr), _nodo_sig(nullptr) {}

        Iterador &operator=(const typename ListaAtomica::Iterador &otro) {
            _lista = otro._lista;
            _nodo_sig = otro._nodo_sig;
            return *this;
        }

        bool haySiguiente() const {
            return _nodo_sig != nullptr;
        }

        T &siguiente() {
            return _nodo_sig->_valor;
        }

        void avanzar() {
            _nodo_sig = _nodo_sig->_siguiente;
        }

        bool operator==(const typename ListaAtomica::Iterador &otro) const {
            return _lista->_cabeza.load() == otro._lista->_cabeza.load()
                && _nodo_sig == otro._nodo_sig;
        }
    };

    Iterador crearIt() {
        return Iterador(this, _cabeza);
    }
};

#elif LISTA_IMP == LISTA_MUTEX

#include <atomic>
#include <pthread.h>

template<typename T>
class ListaAtomica {
 private:
    struct Nodo {
        Nodo(const T &val) : _valor(val), _siguiente(nullptr) {}

        T _valor;
        Nodo *_siguiente;
    };

    std::atomic<Nodo *> _cabeza;
    pthread_mutex_t _mut;

 public:
    ListaAtomica() : _cabeza(nullptr) {
        pthread_mutexattr_t mutAttr;
        pthread_mutexattr_settype(&mutAttr, PTHREAD_MUTEX_ERRORCHECK);
        pthread_mutex_init(&(_mut), &mutAttr);
    }

    ~ListaAtomica() {
        Nodo *n, *t;
        n = _cabeza.load();
        while (n) {
            t = n;
            n = n->_siguiente;
            delete t;
        }
    }

    void insertar(const T &valor) {
        //REM
        //Creo el nodo nuevo
        Nodo* nuevo = new Nodo(valor);
        
        //Pido acceso exclusivo
        pthread_mutex_lock(&(_mut));    //TRY
            //CRIT
            nuevo->_siguiente = _cabeza;
            _cabeza = nuevo;
        pthread_mutex_unlock(&(_mut));  //EXIT
    }

    T &cabeza() const {
        return _cabeza.load()->_valor;
    }

    T &iesimo(unsigned int i) const {
        Nodo *n = _cabeza.load();
        for (unsigned int j = 0; j < i; j++) {
            n = n->_siguiente;
        }
        return n->_valor;
    }

    unsigned int longitud() const {
        Nodo *n = _cabeza.load();
        unsigned int cant = 0;
        while (n != nullptr) {
            cant++;
            n = n->_siguiente;
        }
        return cant;
    }


    class Iterador {
     private:
        ListaAtomica *_lista;

        typename ListaAtomica::Nodo *_nodo_sig;

        Iterador(ListaAtomica<T> *lista, typename ListaAtomica<T>::Nodo *sig)
            : _lista(lista), _nodo_sig(sig) {}

        friend typename ListaAtomica<T>::Iterador ListaAtomica<T>::crearIt();

     public:
        Iterador() : _lista(nullptr), _nodo_sig(nullptr) {}

        Iterador &operator=(const typename ListaAtomica::Iterador &otro) {
            _lista = otro._lista;
            _nodo_sig = otro._nodo_sig;
            return *this;
        }

        bool haySiguiente() const {
            return _nodo_sig != nullptr;
        }

        T &siguiente() {
            return _nodo_sig->_valor;
        }

        void avanzar() {
            _nodo_sig = _nodo_sig->_siguiente;
        }

        bool operator==(const typename ListaAtomica::Iterador &otro) const {
            return _lista->_cabeza.load() == otro._lista->_cabeza.load()
                && _nodo_sig == otro._nodo_sig;
        }
    };

    Iterador crearIt() {
        return Iterador(this, _cabeza);
    }
};

#elif LISTA_IMP == LISTA_SEMAFORO

#include <atomic>
#include <semaphore.h>

template<typename T>
class ListaAtomica {
 private:
    struct Nodo {
        Nodo(const T &val) : _valor(val), _siguiente(nullptr) {}

        T _valor;
        Nodo *_siguiente;
    };

    std::atomic<Nodo *> _cabeza;
    sem_t _sem;

 public:
    ListaAtomica() : _cabeza(nullptr) {
        sem_init(&(_sem), 0, 1);
    }

    ~ListaAtomica() {
        Nodo *n, *t;
        n = _cabeza.load();
        while (n) {
            t = n;
            n = n->_siguiente;
            delete t;
        }
    }

    void insertar(const T &valor) {
        //REM
        //Creo el nodo nuevo
        Nodo* nuevo = new Nodo(valor);
        
        //Pido acceso exclusivo
        sem_wait(&(_sem));              //TRY
            //CRIT
            nuevo->_siguiente = _cabeza;
            _cabeza = nuevo;
        sem_post(&(_sem));              //EXIT
    }

    T &cabeza() const {
        return _cabeza.load()->_valor;
    }

    T &iesimo(unsigned int i) const {
        Nodo *n = _cabeza.load();
        for (unsigned int j = 0; j < i; j++) {
            n = n->_siguiente;
        }
        return n->_valor;
    }

    unsigned int longitud() const {
        Nodo *n = _cabeza.load();
        unsigned int cant = 0;
        while (n != nullptr) {
            cant++;
            n = n->_siguiente;
        }
        return cant;
    }


    class Iterador {
     private:
        ListaAtomica *_lista;

        typename ListaAtomica::Nodo *_nodo_sig;

        Iterador(ListaAtomica<T> *lista, typename ListaAtomica<T>::Nodo *sig)
            : _lista(lista), _nodo_sig(sig) {}

        friend typename ListaAtomica<T>::Iterador ListaAtomica<T>::crearIt();

     public:
        Iterador() : _lista(nullptr), _nodo_sig(nullptr) {}

        Iterador &operator=(const typename ListaAtomica::Iterador &otro) {
            _lista = otro._lista;
            _nodo_sig = otro._nodo_sig;
            return *this;
        }

        bool haySiguiente() const {
            return _nodo_sig != nullptr;
        }

        T &siguiente() {
            return _nodo_sig->_valor;
        }

        void avanzar() {
            _nodo_sig = _nodo_sig->_siguiente;
        }

        bool operator==(const typename ListaAtomica::Iterador &otro) const {
            return _lista->_cabeza.load() == otro._lista->_cabeza.load()
                && _nodo_sig == otro._nodo_sig;
        }
    };

    Iterador crearIt() {
        return Iterador(this, _cabeza);
    }
};

#endif

#endif /* LISTA_ATOMICA_HPP */
