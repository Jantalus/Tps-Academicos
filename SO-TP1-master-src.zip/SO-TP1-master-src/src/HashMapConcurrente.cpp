#ifndef CHM_CPP
#define CHM_CPP

#include <iostream>
#include <fstream>
#include "HashMapConcurrente.hpp"

HashMapConcurrente::HashMapConcurrente() {
    for (unsigned int i=0; i<HashMapConcurrente::cantLetras; ++i) {
        tabla[i] = new ListaAtomica<hashMapPair>();
    }
    cantInc.store(0);
    cantMax.store(0);
}

unsigned int HashMapConcurrente::hashIndex(std::string clave) {
    return (unsigned int)(clave[0] - 'a');
}

void HashMapConcurrente::incrementar(std::string clave) {
    turnstile.acquire();
        if(cantInc.fetch_add(1)==0) nadie.acquire();        //Si antes no había nadie ejecutando 'incrementar', espero a que terminen de ejecutar 'maximo' o 'maximoParalelo'
    turnstile.release();                                    //Le permito el paso a algún thread que quiera ejecutar 'incrementar', 'maximo' o 'maximoParalelo'

    /******************************************************************************/

    unsigned int index = HashMapConcurrente::hashIndex(clave);
    
    locks[index].acquire();                                 //Pido acceso exclusivo al bucket que le corresponde a 'clave'
        //Sección crítica
        auto it = tabla[index]->crearIt();
        while(it.haySiguiente() && it.siguiente().first!=clave)
            it.avanzar();
        if(it.haySiguiente())                               //Ya hay un hashMapPair que tiene miembro first==clave
            it.siguiente().second++;
        else{                                               //Debo agregar <clave, 1> al principio de *(tabla[index])
            hashMapPair temp = {clave, 1};
            tabla[index]->insertar(temp);
        }
    locks[index].release();

    /******************************************************************************/

    if(cantInc.fetch_add(-1)==1) nadie.release();           //Si soy el último en ejecutar 'incrementar', aviso que ya no hay nadie ejecutando
}

std::vector<std::string> HashMapConcurrente::claves() {
    std::vector<std::string> res;
    for(unsigned int i = 0; i<HashMapConcurrente::cantLetras; ++i){
        auto it = tabla[i]->crearIt();
        while(it.haySiguiente()){
            res.push_back(it.siguiente().first);
            it.avanzar();
        }
    }
    return res;
}

unsigned int HashMapConcurrente::valor(std::string clave) {
    unsigned int index = HashMapConcurrente::hashIndex(clave);
    auto it = tabla[index]->crearIt();
    while(it.haySiguiente() && it.siguiente().first!=clave)
        it.avanzar();
    
    if(it.haySiguiente())               //Encontré hashMapPair con miembro first==clave
        return it.siguiente().second;
    else                                //'clave' no se registró ninguna vez
        return 0;
}

hashMapPair HashMapConcurrente::maximo() {
    turnstile.acquire();
        if(cantMax.fetch_add(1)==0) nadie.acquire();        //Si antes no había nadie ejecutando una operación de máximo, espero a que termine de ejecutar 'incremento'
    turnstile.release();                                    //Le permito el paso a algún thread que quiera ejecutar 'incrementar', 'maximo' o 'maximoParalelo'

    /******************************************************************************/

    hashMapPair *max = new hashMapPair();
    max->second = 0;

    for (unsigned int index = 0; index < HashMapConcurrente::cantLetras; index++) {
        for (
            auto it = tabla[index]->crearIt();
            it.haySiguiente();
            it.avanzar()
        ) {
            if (it.siguiente().second > max->second) {
                max->first = it.siguiente().first;
                max->second = it.siguiente().second;
            }
        }
    }

    /******************************************************************************/

    if(cantMax.fetch_add(-1)==1) nadie.release();           //Si soy el último en ejecutar una operación de máximo, aviso que ya no hay nadie ejecutando

    return *max;
}

struct params_maxParcial {
    HashMapConcurrente* este;                               //El HMC con el que estamos trabajando
    std::atomic<unsigned int>* bucket;                      //Esta variable equivale a "el bucket de menor índice que todavía no haya sido tomado"
    std::vector<hashMapPair>* res;                          //En este vector se almacenan los "máximos parciales"
    unsigned int index;                                     //Ésta es la posición del vector 'res' donde cada thread guarda su "máximo parcial"
};

hashMapPair HashMapConcurrente::maxBucket(unsigned int i){
    hashMapPair max = {"",0};
    for (auto it = tabla[i]->crearIt(); it.haySiguiente(); it.avanzar()){
        if (it.siguiente().second > max.second) {
            max.first = it.siguiente().first;
            max.second = it.siguiente().second;
        }
    }
    return max;
}

void* maxParcial(void* algo){
    params_maxParcial& p = *((params_maxParcial*)algo);

    //Recibo los parámetros almacenados en 'p'
    HashMapConcurrente& h = *(p.este);
    std::atomic<unsigned int>& buckets = *(p.bucket);
    std::vector<hashMapPair>& res = *(p.res);
    unsigned int miResIndex = p.index;

    hashMapPair max = {"",0};                               //Acá voy a acumular el máximo
    hashMapPair temp;
    unsigned int cantLetras = 26;
    unsigned int index;

    //Tomo el valor actual de 'buckets' y lo incremento para que los demás threads no tomen el mismo bucket que yo.
    //Si el valor de 'buckets' ya era mayor o igual a 26, es porque no quedan buckets y puedo terminar mi ejecución.
    while((index = buckets.fetch_add(1))<cantLetras){
        temp = h.maxBucket(index);
        if(temp.second > max.second){
            max.first = temp.first;
            max.second = temp.second;
        }
    }
    res[miResIndex] = max;
    return nullptr;
}

hashMapPair HashMapConcurrente::maximoParalelo(unsigned int cantThreads) {
    turnstile.acquire();
        if(cantMax.fetch_add(1)==0) nadie.acquire();        //Si antes no había nadie ejecutando una operación de máximo, espero a que termine de ejecutar 'incremento'
    turnstile.release();                                    //Le permito el paso a algún thread que quiera ejecutar 'incrementar', 'maximo' o 'maximoParalelo'

    /******************************************************************************/

    std::vector<hashMapPair> res(cantThreads);
    std::atomic<unsigned int> b;
    b.store(0);
    std::vector<params_maxParcial> params(cantThreads);

    for(unsigned int i=0; i<cantThreads; ++i){
        params[i].este = this;
        params[i].bucket = &b;
        params[i].res = &res;
        params[i].index = i;
    }

    std::vector<pthread_t> tids(cantThreads);
    for(unsigned int i=0; i<cantThreads; ++i)
        pthread_create(&tids[i], nullptr, maxParcial, &(params[i]));
    for(unsigned int i=0; i<cantThreads; ++i)
        pthread_join(tids[i], nullptr);
            
    /******************************************************************************/
    
    if(cantMax.fetch_add(-1)==1) nadie.release();           //Si soy el último en ejecutar una operación de máximo, aviso que ya no hay nadie ejecutando

    hashMapPair max = {"",0};                               //Acá voy a acumular el "máximo total"
    for(unsigned int i=0; i<cantThreads; ++i){              //Recorro todos los resultados parciales
        if(res[i].second > max.second){
            max.first = res[i].first;
            max.second = res[i].second;
        }
    }
    return max;
}

#endif