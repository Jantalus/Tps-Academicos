/* Test de overhead para ListaAtomica */

#include <cstdio>
#include <cstdlib>
#include <chrono>
#include <vector>
#include <pthread.h>
#include "../ListaAtomica.hpp"

struct params_insertLista{
    ListaAtomica<int> *listaCompartida;
    unsigned int num;
    unsigned int its;
};

void* insertLista(void* p){
    params_insertLista params = *((params_insertLista*)p);

    for(unsigned int i=0; i<params.its; ++i)
        params.listaCompartida->insertar(params.num);

    return nullptr;
}

int main(int argc, char* argv[]){
    ListaAtomica<int> lista;
    if(argc!=3){
        printf("Faltan o sobran parámetros!\n Uso: ./testOverheadListaAtomica <CANTIDAD DE THREADS CONCURRENTES> <CANTIDAD DE INSERCIONES POR THREAD>\n");
        return 1;
    }
    int cantThreads = std::atoi(argv[1]);
    int its = std::atoi(argv[2]);

    std::vector<pthread_t> tids(cantThreads);

    std::vector<params_insertLista> params(cantThreads);

    for(unsigned int i=0; i<params.size(); ++i){
        params[i].listaCompartida = &lista;
        params[i].num = i;
        params[i].its = its;
    }

    auto start = std::chrono::steady_clock::now();
    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_create(&(tids[i]), nullptr, insertLista, &params[i]);
    }
    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_join(tids[i], nullptr);
    }
    auto end = std::chrono::steady_clock::now();
	double delta = std::chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
    printf("%f\n", delta);
}
