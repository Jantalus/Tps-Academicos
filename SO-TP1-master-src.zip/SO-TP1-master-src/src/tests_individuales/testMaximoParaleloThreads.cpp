/* Test de scaling según el threading en cargarMultiplesArchivos */

#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <time.h>
#include <pthread.h>
#include "../CargarArchivos.cpp"
#include "../HashMapConcurrente.cpp"

const int NS_POR_SEGUNDO = 1000000000;

void create_delta(struct timespec t1, struct timespec t2, struct timespec *td){
    td->tv_nsec = t2.tv_nsec - t1.tv_nsec;
    td->tv_sec  = t2.tv_sec - t1.tv_sec;
    if (td->tv_sec > 0 && td->tv_nsec < 0)
    {
        td->tv_nsec += NS_POR_SEGUNDO;
        td->tv_sec--;
    }
    else if (td->tv_sec < 0 && td->tv_nsec > 0)
    {
        td->tv_nsec -= NS_POR_SEGUNDO;
        td->tv_sec++;
    }
}

double getDelta(timespec ti, timespec tf){
    long d_s = tf.tv_sec-ti.tv_sec;
    long d_ns = tf.tv_nsec-ti.tv_nsec;
    if(d_s>0 && d_ns<0){
        d_ns += NS_POR_SEGUNDO;
        d_s--;
    }
    else if(d_s<0 && d_ns>0){
        d_ns -= NS_POR_SEGUNDO;
        d_s++;
    }
    double res = (double)(NS_POR_SEGUNDO*d_s + d_ns)/NS_POR_SEGUNDO;
    return res;
}

struct params_incrementarHMC{
    HashMapConcurrente* HMCcompartido;
    unsigned int its;
    char inicial;
    char segundo;
};

void* incrementarHMC(void* p){
    params_incrementarHMC params = *((params_incrementarHMC*)p);
    HashMapConcurrente& h = *params.HMCcompartido;
    unsigned int its = params.its;
    char ini = params.inicial;
    char seg = params.segundo;

    std::string clave;
    clave.push_back(ini);
    for(unsigned int i=0; i<its; ++i){
        clave.push_back(seg);
        h.incrementar(clave);
    }

    return nullptr;
}

int main(int argc, char* argv[]){
    std::vector<std::string> filePathsOptimo = {"data/a.txt", "data/b.txt", "data/c.txt", "data/d.txt", "data/e.txt", "data/f.txt",
                                                "data/g.txt", "data/h.txt", "data/i.txt", "data/j.txt", "data/k.txt", "data/l.txt", 
                                                "data/m.txt", "data/n.txt", "data/o.txt", "data/p.txt", "data/q.txt", "data/r.txt", "data/s.txt",
                                                "data/t.txt", "data/u.txt", "data/v.txt", "data/w.txt", "data/x.txt", "data/y.txt", "data/z.txt"};
    std::vector<std::string> filePathsPesimo = {"data/a1.txt", "data/a2.txt", "data/a3.txt", "data/a4.txt", "data/a5.txt", "data/a6.txt", "data/a7.txt", "data/a8.txt",
                                                "data/a9.txt", "data/a10.txt", "data/a11.txt", "data/a12.txt", "data/a13.txt", "data/a14.txt", "data/a15.txt", "data/a16.txt"};

    HashMapConcurrente h;
    if(argc!=2){
        printf("Faltan o sobran parámetros!\n Uso: ./build/testMaximoParaleloThreads <CASO>\nDonde CASO es:\n\t0 - Cada archivo tiene palabras que empiezan con una letra particular\n\t1 - Todos los archivos tienen palabras que empiezan con la misma letra\n");
        return 1;
    }
    unsigned int caso = std::atoi(argv[1]);
    timespec start, finish;
    if(caso==0){
        cargarMultiplesArchivos(h, 5, filePathsOptimo);
    }
    else if(caso==1){
        cargarMultiplesArchivos(h, 1, filePathsPesimo);
    }

    std::vector<std::string> temp = h.claves();
    int maxThreads = 32;
    int its = 50;
    double acum;
    std::vector<float> deltas(maxThreads);

    for(int t=1; t<=maxThreads; ++t){
        printf("t=%d\n", t);
        acum = 0;
        for(int i=0; i<its; ++i){
            clock_gettime(CLOCK_REALTIME, &start);
            hashMapPair max = h.maximoParalelo(t);
            clock_gettime(CLOCK_REALTIME, &finish);
            acum += getDelta(start, finish);
        }
        deltas[t-1] = acum/its;
    }
    printf("[");
    for(int i=0; i<maxThreads-1; ++i){
        printf("%f,", deltas[i]);
    }
    printf("%f", deltas[maxThreads-1]);
    printf("]\n");
}
