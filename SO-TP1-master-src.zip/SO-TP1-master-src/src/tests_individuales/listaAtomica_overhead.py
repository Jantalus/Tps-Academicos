import subprocess
import sys
import os.path
import matplotlib

if len(sys.argv)!=4:
    print("Faltan o sobran parámetros!\n Uso: ./TEST_lista_overhead <THREADS> <INSERCIONES POR THREAD> <CANTIDAD DE ITERACIONES>\n")
    sys.exit(1)

nameTest = "testOverheadListaAtomica"
nameSpinlock = "testOverheadListaAtomica_spinlock"
nameMutex = "testOverheadListaAtomica_mutex"
nameSemaforo= "testOverheadListaAtomica_semaforo"

if not (os.path.exists('build') and os.path.isfile('build/'+nameSpinlock) and os.path.isfile('build/'+nameMutex) and os.path.isfile('build/'+nameSemaforo)):
    print("Para usar este programa, antes debe:\n")
    print(F"1. Invocar 'make {nameTest}' definiendo #define LISTA_IMP LISTA_SPINLOCK en ListaAtomica.hpp, renombrar el ejecutable a '{nameSpinlock}'\n")
    print(F"2. Invocar 'make {nameTest}' definiendo #define LISTA_IMP LISTA_MUTEX en ListaAtomica.hpp, renombrar el ejecutable a '{nameMutex}'\n")
    print(F"3. Invocar 'make {nameTest}' definiendo #define LISTA_IMP LISTA_SEMAFORO en ListaAtomica.hpp, renombrar el ejecutable a '{nameSemaforo}'\n")
    sys.exit(1)

threads = int(sys.argv[1])
inserciones = int(sys.argv[2])
its = int(sys.argv[3])

acum=0
for i in range(its):
    result = subprocess.run([F'./build/{nameSpinlock}', str(threads), str(inserciones)], stdout=subprocess.PIPE)
    acum+=float(result.stdout.decode("utf-8").strip('\n'))

print("Overhead de ListaAtomica para Spinlock:", acum)

acum=0
for i in range(its):
    result = subprocess.run([F'./build/{nameMutex}', str(threads), str(inserciones)], stdout=subprocess.PIPE)
    acum+=float(result.stdout.decode("utf-8").strip('\n'))

print("Overhead de ListaAtomica para Mutex:", acum)

acum=0
for i in range(its):
    result = subprocess.run([F'./build/{nameSemaforo}', str(threads), str(inserciones)], stdout=subprocess.PIPE)
    acum+=float(result.stdout.decode("utf-8").strip('\n'))

print("Overhead de ListaAtomica para Semáforo:", acum)
