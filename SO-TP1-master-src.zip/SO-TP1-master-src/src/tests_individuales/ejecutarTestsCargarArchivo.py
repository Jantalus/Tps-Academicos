import matplotlib.pyplot as plt
import subprocess
import os

if not os.path.exists('data'):
    os.makedirs('data')

subprocess.run(["python3", "crearArchivosParaCadaInicial.py", "3"])
subprocess.run(["python3", "crearArchivosParaMismaInicial.py", "4", "16"])
subprocess.run(["make", "testCargarArchivoThreads"])

mediaDistintaInicial = []
mediaMismaInicial = []
its = 5
threadsMaxDistinta = 33
threadsMaxMisma = 9

for t in range(1,threadsMaxDistinta):
    print(F"DistintaInicial, {t} threads\n")
    acum = 0
    for i in range(its):
        result = subprocess.run(['build/testCargarArchivoThreads', str(t), "0"], stdout=subprocess.PIPE)
        acum += float(result.stdout)
    mediaDistintaInicial.append(acum/its)

for t in range(1,threadsMaxMisma):
    print(F"MismaInicial, {t} threads\n")
    acum = 0
    for i in range(its):
        result = subprocess.run(['build/testCargarArchivoThreads', str(t), "1"], stdout=subprocess.PIPE)
        acum += float(result.stdout)
    mediaMismaInicial.append(acum/its)

fig,a =  plt.subplots(2,1)
x0 = range(1,33)
x1 = range(1,9)
a[0].bar(x0, mediaDistintaInicial)
a[0].set_xlabel("Cantidad de threads")
a[0].set_ylabel("Tiempo de ejecución (segundos)")
a[0].set_title("Caso óptimo")
a[1].bar(x1, mediaMismaInicial)
a[1].set_xlabel("Cantidad de threads")
a[1].set_ylabel("Tiempo de ejecución (segundos)")
a[1].set_title("Caso desventajoso")

plt.tight_layout()
plt.show()

print(mediaDistintaInicial)
print(mediaMismaInicial)