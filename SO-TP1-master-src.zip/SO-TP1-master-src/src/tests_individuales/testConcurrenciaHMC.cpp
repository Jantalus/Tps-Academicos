/* Test de concurrencia para HashMapConcurrente */

#include <cstdio>
#include <string>
#include <vector>
#include <pthread.h>
#include "../HashMapConcurrente.cpp"

struct params_HMC{
    HashMapConcurrente& HMCCompartido;
    unsigned int& its;
};

const unsigned int cantLetras = 26;

const char* claves[] =   {"about", "below", "cost", "dearest", "eager", "floater", "great",
                    "hollow", "indexed", "jail", "kindest", "lupus", "manual", "number",
                    "often", "parsed", "question", "remain", "stance", "traded", "useful",
                    "value", "wanted", "xavier", "youth", "zero" };

void* incHashMap(void* p){
    params_HMC params = *((params_HMC*)p);
    unsigned int its = params.its;

    for(unsigned int i=0; i<its; ++i){
        params.HMCCompartido.incrementar(claves[i%cantLetras]);
        printf("incremento: \"%s\"\n", claves[i%cantLetras]);
    }

    printf("\t\t\tFin de los incrementos\n");
    return nullptr;
}

void* clavesHashMap(void* p){
    params_HMC params = *((params_HMC*)p);
    unsigned int its = params.its;
    std::vector<std::string> k;

    for(unsigned int i=0; i<its; ++i){
        k = params.HMCCompartido.claves();
        printf("lectura de claves\n");
    }

    printf("\t\t\tFin de las lecturas de claves\n");
    return nullptr;
}

void* valorHashMap(void* p){
    params_HMC params = *((params_HMC*)p);
    unsigned int its = params.its;
    unsigned int temp;
    for(unsigned int i=0; i<its; ++i){
        temp = params.HMCCompartido.valor(claves[cantLetras-1 - (i%cantLetras)]);
        printf("valor de %s: %d\n", claves[cantLetras-1 - (i%cantLetras)], temp);
    }

    printf("\t\t\tFin de las lecturas de valores\n");
    return nullptr;
}

void* maxHashMap(void* p){
    params_HMC params = *((params_HMC*)p);
    unsigned int its = params.its;
    hashMapPair temp;
    for(unsigned int i=0; i<its; ++i){
        temp = params.HMCCompartido.maximo();
        printf("máximo: <%s,%d>\n", temp.first.c_str(), temp.second);
    }
    
    printf("\t\t\tFin de los cálculos de máximo\n");
    return nullptr;
}

void* maxParaleloHashMap(void* p){
    params_HMC params = *((params_HMC*)p);
    unsigned int its = params.its;
    hashMapPair temp;
    for(unsigned int i=0; i<its; ++i){
        temp = params.HMCCompartido.maximoParalelo(8);
        printf("máximoParalelo: <%s,%d>\n", temp.first.c_str(), temp.second);
    }
    
    printf("\t\t\tFin de los cálculos de máximoParalelo\n");
    return nullptr;
}

int main(int argc, char* argv[]){
    HashMapConcurrente h;
    int cantThreads = 5;
    unsigned int its = 52;
    std::vector<pthread_t> tids(cantThreads);

    params_HMC p = {h, its};

    pthread_create(&(tids[0]), nullptr, incHashMap, &p);
    pthread_create(&(tids[1]), nullptr, clavesHashMap, &p);
    pthread_create(&(tids[2]), nullptr, valorHashMap, &p);
    pthread_create(&(tids[3]), nullptr, maxHashMap, &p);
    pthread_create(&(tids[4]), nullptr, maxParaleloHashMap, &p);
    
    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_join(tids[i], nullptr);
    }
    
    printf("*******************************************\n\n");
    printf("Fin de la ejecución. Estado actual del HMC:\n\n");
    printf("******************************************\n");
    unsigned int temp;
    for(unsigned int i=0; i<cantLetras; ++i){
        temp = h.valor(claves[i%cantLetras]);
        printf("Cantidad de apariciones de %s: %d\n", claves[i%cantLetras], temp);
    }
    return 0;
}
