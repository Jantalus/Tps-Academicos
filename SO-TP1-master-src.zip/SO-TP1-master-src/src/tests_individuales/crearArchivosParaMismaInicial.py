import itertools
import sys
import os

nombreScript = sys.argv[0]
cantArgs = 3

if len(sys.argv)!=cantArgs:
    sys.exit(F"Faltan o sobran parámetros!\n Uso: {nombreScript} <COTA DE LONGITUD> <PARTES>\n")

abecedario = 'abcdefghijklmnopqrstuvwxyz'
longMax = int(sys.argv[1])
partes = int(sys.argv[2])

permutaciones = []
for i in range(1,longMax):
    permutaciones.append(["a"+''.join(x) for x in itertools.product(abecedario, repeat=i)])

total = [j for i in permutaciones for j in i]
total.insert(0,"a")
tamParte = len(total)//partes

if not os.path.exists('data'):
    os.makedirs('data')

for i in range(partes):
    with open("data/a"+str(i+1)+".txt", "w") as file:
        for l in total[i*tamParte:(i+1)*tamParte]:
            file.write(l)
            file.write(" ")