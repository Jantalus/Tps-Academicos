/* ¿Puede un programa que utiliza ListaAtomica incurrir en condiciones de carrera? */

#include <cstdio>
#include <iostream>
#include <vector>
#include <pthread.h>
#include "../ListaAtomica.hpp"

struct params_insertLista{
    ListaAtomica<int> *listaCompartida;
    unsigned int num;
};

template <class T>
void imprimirLista(ListaAtomica<T>& l){
    unsigned int size = l.longitud();

    auto ult = l.crearIt();
    auto fin = l.crearIt();
    while(fin.haySiguiente()){
        ult = fin;
        fin.avanzar();
    }

    std::cout << "[";
    auto it = l.crearIt();
    while(!(it==ult)){
        std::cout << it.siguiente();
        std::cout << ", ";
        it.avanzar();
    }

    if(size>0)
        std::cout << it.siguiente();
    std::cout << "]\n";
}

void* insertLista(void* p){
    params_insertLista params = *((params_insertLista*)p);
    params.listaCompartida->insertar(params.num);
    printf("Se insertó %d\n", params.num);
    return nullptr;
}

int main(){
    ListaAtomica<int> lista;
    int cantThreads = 16;

    std::vector<pthread_t> tids(cantThreads);
    std::vector<params_insertLista> params(cantThreads);

    for(unsigned int i=0; i<params.size(); ++i){
        params[i].listaCompartida = &lista;
        params[i].num = i;
    }
    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_create(&(tids[i]), nullptr, insertLista, &params[i]);
    }
    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_join(tids[i], nullptr);
    }
    imprimirLista(lista);
    printf("Ejecutar varias veces para observar que existe una condición de carrera sobre el valor de la lista.\n");
    return 0;
}