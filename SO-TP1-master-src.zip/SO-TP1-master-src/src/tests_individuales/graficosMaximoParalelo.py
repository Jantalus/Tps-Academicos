import matplotlib.pyplot as plt
import numpy as np

distinta = [0.005223,0.002681,0.002091,0.002111,0.002382,0.002169,0.002316,0.002134,0.002636,0.002227,0.002272,0.002215,0.002340,0.002354,0.002290,0.002329,0.002502,0.002380,0.002322,0.002455,0.002341,0.002317,0.002550,0.002766,0.002338,0.002457,0.002428,0.002504,0.002407,0.002458,0.002804,0.002560]
misma = [0.000214,0.000218,0.000232,0.000392,0.000373,0.000346,0.000373,0.000408,0.000411,0.000452,0.000563,0.000419,0.000620,0.000417,0.000461,0.000389,0.000412,0.000472,0.000467,0.000444,0.000527,0.000548,0.000593,0.000601,0.000576,0.000525,0.000660,0.000602,0.000804,0.000732,0.000833,0.000870]

fig,a =  plt.subplots(2,1)
x0 = np.arange(1,33)
x1 = np.arange(1,33)
a[0].bar(x0, distinta)
a[0].set_xticks([1]+[4*i for i in range(1,9)])
a[0].set_xlabel("Cantidad de threads")
a[0].set_ylabel("Tiempo de ejecución (seg)")
a[0].set_title("maximoParalelo - distintas iniciales")
a[1].bar(x1, misma)
a[1].set_xlabel("Cantidad de threads")
a[1].set_ylabel("Tiempo de ejecución (seg)")
a[1].set_title("maximoParalelo - inicial única")

plt.tight_layout()
plt.show()