import itertools
import sys
import os

nombreScript = sys.argv[0]
cantArgs = 2

if len(sys.argv)!=cantArgs:
    sys.exit(F"Faltan o sobran parámetros!\n Uso: {nombreScript} <COTA DE LONGITUD>\n")

abecedario = 'abcdefghijklmnopqrstuvwxyz'
longMax = int(sys.argv[1])

permutaciones = []
for i in range(1,longMax):
    permutaciones.append([''.join(x) for x in itertools.product(abecedario, repeat=i)])

if not os.path.exists('data'):
    os.makedirs('data')

for letra in abecedario:
    with open("data/"+letra+".txt", "w") as file:
        file.write(letra)
        file.write(" ")
        for i in range(0,longMax-1):
            for perm in permutaciones[i]:
                file.write(letra+perm)
                file.write(" ")