/* Test de concurrencia para ListaAtomica */

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <vector>
#include <pthread.h>
#include "../ListaAtomica.hpp"

struct params_insertLista{
    ListaAtomica<int>& listaCompartida;
    int& cantThreads;
};

template <class T>
void imprimirLista(ListaAtomica<T>& l){
    unsigned int size = l.longitud();

    auto ult = l.crearIt();
    auto fin = l.crearIt();
    while(fin.haySiguiente()){
        ult = fin;
        fin.avanzar();
    }

    std::cout << "[";
    auto it = l.crearIt();
    while(!(it==ult)){
        std::cout << it.siguiente();
        std::cout << ", ";
        it.avanzar();
    }

    if(size>0)
        std::cout << it.siguiente();
    std::cout << "]\n";
}

void* insertLista(void* p){
    params_insertLista params = *((params_insertLista*)p);

    //Número entre 1 y N, donde N es la cantidad de threads
    int miValor = rand() % params.cantThreads + 1;
    
    params.listaCompartida.insertar(miValor);
    printf("Uno de los threads insertó: %d\n", miValor);

    return nullptr;
}

int main(int argc, char* argv[]){
    srand (time(NULL));
    ListaAtomica<int> lista;
    if(argc!=2){
        printf("Faltan o sobran parámetros!\n Uso: ./testConcurrenciaListaAtomica <CANTIDAD DE THREADS CONCURRENTES>\n");
        return 1;
    }
    int cantThreads = std::atoi(argv[1]);
    std::vector<pthread_t> tids(cantThreads);

    params_insertLista p = {lista, cantThreads};

    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_create(&(tids[i]), nullptr, insertLista, &p);
    }
    for(unsigned int i=0; i<tids.size(); ++i){
        pthread_join(tids[i], nullptr);
    }
    imprimirLista(lista);
    printf("Longitud: %d\n", lista.longitud());
}