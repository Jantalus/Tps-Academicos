import subprocess
import sys
import os

nombreScript = sys.argv[0]
cantArgs = 2

if len(sys.argv)!=cantArgs:
    sys.exit(F"Faltan o sobran parámetros!\n Uso: {nombreScript} <CASO>\nDonde CASO es:\n\t0 - Cada archivo tiene palabras que empiezan con una letra particular\n\t1 - Todos los archivos tienen palabras que empiezan con la misma letra\n")

caso = sys.argv[1]

if not os.path.exists('data'):
    os.makedirs('data')

subprocess.run(["python3", "crearArchivosParaCadaInicial.py", "3"])
subprocess.run(["python3", "crearArchivosParaMismaInicial.py", "4", "16"])
subprocess.run(["make", "testMaximoParaleloThreads"])

subprocess.run(["build/testMaximoParaleloThreads", caso])