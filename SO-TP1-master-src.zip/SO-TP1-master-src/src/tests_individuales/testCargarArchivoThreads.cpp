/* Test de scaling según el threading en cargarMultiplesArchivos */

#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <time.h>
#include <pthread.h>
#include "../CargarArchivos.cpp"
#include "../HashMapConcurrente.cpp"

const int NS_POR_SEGUNDO = 1000000000;

void getDelta(struct timespec t1, struct timespec t2, struct timespec *td){
    td->tv_nsec = t2.tv_nsec - t1.tv_nsec;
    td->tv_sec  = t2.tv_sec - t1.tv_sec;
    if (td->tv_sec > 0 && td->tv_nsec < 0)
    {
        td->tv_nsec += NS_POR_SEGUNDO;
        td->tv_sec--;
    }
    else if (td->tv_sec < 0 && td->tv_nsec > 0)
    {
        td->tv_nsec -= NS_POR_SEGUNDO;
        td->tv_sec++;
    }
}

struct params_incrementarHMC{
    HashMapConcurrente* HMCcompartido;
    unsigned int its;
    char inicial;
    char segundo;
};

void* incrementarHMC(void* p){
    params_incrementarHMC params = *((params_incrementarHMC*)p);
    HashMapConcurrente& h = *params.HMCcompartido;
    unsigned int its = params.its;
    char ini = params.inicial;
    char seg = params.segundo;

    std::string clave;
    clave.push_back(ini);
    for(unsigned int i=0; i<its; ++i){
        clave.push_back(seg);
        h.incrementar(clave);
    }

    return nullptr;
}

int main(int argc, char* argv[]){
    std::vector<std::string> filePathsOptimo = {"data/a.txt", "data/b.txt", "data/c.txt", "data/d.txt", "data/e.txt", "data/f.txt",
                                                "data/g.txt", "data/h.txt", "data/i.txt", "data/j.txt", "data/k.txt", "data/l.txt", 
                                                "data/m.txt", "data/n.txt", "data/o.txt", "data/p.txt", "data/q.txt", "data/r.txt", "data/s.txt",
                                                "data/t.txt", "data/u.txt", "data/v.txt", "data/w.txt", "data/x.txt", "data/y.txt", "data/z.txt"};
    std::vector<std::string> filePathsPesimo = {"data/a1.txt", "data/a2.txt", "data/a3.txt", "data/a4.txt", "data/a5.txt", "data/a6.txt", "data/a7.txt", "data/a8.txt",
                                                "data/a9.txt", "data/a10.txt", "data/a11.txt", "data/a12.txt", "data/a13.txt", "data/a14.txt", "data/a15.txt", "data/a16.txt"};
    HashMapConcurrente h;
    if(argc!=3){
        printf("Faltan o sobran parámetros!\n Uso: ./build/testCargarArchivoThreads <CANTIDAD DE THREADS CONCURRENTES> <CASO>\nDonde CASO es:\n\t0 - Cada archivo tiene palabras que empiezan con una letra particular\n\t1 - Todos los archivos tienen palabras que empiezan con la misma letra\n");
        return 1;
    }
    unsigned int cantThreads = std::atoi(argv[1]);
    unsigned int caso = std::atoi(argv[2]);
    timespec start, finish, delta;
    if(caso==0){
        clock_gettime(CLOCK_REALTIME, &start);
        cargarMultiplesArchivos(h, cantThreads, filePathsOptimo);
        clock_gettime(CLOCK_REALTIME, &finish);
    }
    else if(caso==1){
        clock_gettime(CLOCK_REALTIME, &start);
        cargarMultiplesArchivos(h, cantThreads, filePathsPesimo);
        clock_gettime(CLOCK_REALTIME, &finish);
    }
    getDelta(start, finish, &delta);
    printf("%d.%.9ld\n", (int)delta.tv_sec, delta.tv_nsec);
}