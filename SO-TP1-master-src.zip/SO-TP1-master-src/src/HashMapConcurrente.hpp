#ifndef HMC_HPP
#define HMC_HPP

#include <atomic>
#include <string>
#include <vector>
#include <pthread.h>
#include "ListaAtomica.hpp"
#include "Spinlock.hpp"

typedef std::pair<std::string, unsigned int> hashMapPair;

class HashMapConcurrente {
 public:
    static const unsigned int cantLetras = 26;

    HashMapConcurrente();

    void incrementar(std::string clave);
    std::vector<std::string> claves();
    unsigned int valor(std::string clave);

    hashMapPair maximo();
    hashMapPair maximoParalelo(unsigned int cantThreads);
    hashMapPair maxBucket(unsigned int i);                              //Devuelve el hashMapPair máximo del i-ésimo bucket de la tabla

 private:
    ListaAtomica<hashMapPair> *tabla[HashMapConcurrente::cantLetras];
    Spinlock locks[HashMapConcurrente::cantLetras];                     //Estos locks impiden que se ejecuten concurrentemente varios 'incrementar' sobre un mismo bucket
    Spinlock turnstile, nadie;                                          //Estos locks controlan la exclusión mutua entre la operación 'incrementar' y las operaciones 'maximo' y 'maximoParalelo'
    std::atomic<unsigned int> cantInc, cantMax;                         //Codifica la cantidad de threads que se encuentran ejecutando la función 'incrementar'

    static unsigned int hashIndex(std::string clave);
};

#endif  /* HMC_HPP */
