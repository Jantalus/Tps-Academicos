#ifndef HMC_ARCHIVOS_CPP
#define HMC_ARCHIVOS_CPP

#include <vector>
#include <iostream>
#include <fstream>
#include <pthread.h>

#include "CargarArchivos.hpp"

int cargarArchivo(
    HashMapConcurrente &hashMap,
    std::string filePath
) {
    std::fstream file;
    int cant = 0;
    std::string palabraActual;
    // Abro el archivo.
    file.open(filePath, file.in);
    if (!file.is_open()) {
        std::cerr << "Error al abrir el archivo '" << filePath << "'" << std::endl;
        return -1;
    }
    while (file >> palabraActual) {
        hashMap.incrementar(palabraActual);
        cant++;
    }
    // Cierro el archivo.
    if (!file.eof()) {
        std::cerr << "Error al leer el archivo" << std::endl;
        file.close();
        return -1;
    }
    file.close();
    return cant;
}

struct params_cargarParcial{
    HashMapConcurrente* h;                      //El HMC con el que estamos trabajando
    std::atomic<unsigned int>* fileIndex;       //Esta variable equivale a "el archivo de menor índice que todavía no haya sido tomado"
    std::vector<std::string>* filePaths;        //El conjunto de archivos que se quieren leer
};

void* cargarParcial(void* algo){
    params_cargarParcial& p = *((params_cargarParcial*)algo);

    //Recibo los parámetros almacenados en 'p'
    HashMapConcurrente& h = *(p.h);
    std::atomic<unsigned int>& fileIndex = *(p.fileIndex);
    std::vector<std::string>& filePaths = *(p.filePaths);

    unsigned int cant = filePaths.size();
    unsigned int index;

    //Tomo el valor actual de 'fileIndex' y lo incremento para que los demás threads no carguen el mismo archivo que yo.
    //Si el valor de 'fileIndex' ya era mayor o igual a la cantidad de archivos a cargar, es porque no quedan archivos y puedo terminar mi ejecución.
    while((index = fileIndex.fetch_add(1))<cant){
        cargarArchivo(h, filePaths[index]);
    }
    return nullptr;
}

void cargarMultiplesArchivos(
    HashMapConcurrente &hashMap,
    unsigned int cantThreads,
    std::vector<std::string> filePaths
) {
    std::vector<pthread_t> tids(cantThreads);
    std::atomic<unsigned int> fileIndex;
    fileIndex.store(0);
    std::vector<params_cargarParcial> params(cantThreads);

    for(unsigned int i=0; i<cantThreads; ++i){
        params[i].h = &hashMap;
        params[i].fileIndex = &fileIndex;
        params[i].filePaths = &filePaths;
    }

    for(unsigned int i=0; i<cantThreads; ++i)
        pthread_create(&tids[i], nullptr, cargarParcial, &(params[i]));
    for(unsigned int i=0; i<cantThreads; ++i)
        pthread_join(tids[i], nullptr);
}

#endif
