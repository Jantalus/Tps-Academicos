import sys
import random
def habilitarIslas(cantidadIslas):
    islasHabilitadas = []
    for i in range(cantidadIslas):
        islasHabilitadas.append(i)
    return islasHabilitadas
#--------------------------------------------------------------------------

def crearIslasVacias(cantidadIslas):
    islas = []
    for i in range(cantidadIslas):
        islas.append([])
    return islas
#--------------------------------------------------------------------------
def usage():
    if len(sys.argv) != 5:
        print('Wrong Usage! Needs 4 parameters:\n [Team Amount][Isle Size][Isle Amount][output filename] \n')
        quit()
#--------------------------------------------------------------------------
def separarEquiposEnIslas(cantidadEquipos, tamanoIslas, cantidadIslas):
    islas = crearIslasVacias(cantidadIslas) 
    islasHabilitadas = habilitarIslas(cantidadIslas) 

    i = 0
    while i in range(cantidadEquipos) and len(islasHabilitadas) > 0:
        isla = random.choice(islasHabilitadas)
        islas[isla].append(i)

        if len(islas[isla]) == tamanoIslas:
            islasHabilitadas.remove(isla)
        i = i+1
    if i < cantidadEquipos:
        islaGrande = []
        for j in range(i,cantidadEquipos):
            islaGrande.append(j)
        islas.append(islaGrande)
    return islas
#--------------------------------------------------------------------------
def contarPartidos(islas):
    cantidadPartidos = 0
    for isla_index in range(len(islas)):
        for equipo_index in range(len(islas[isla_index])):
            cantidadPartidos = cantidadPartidos + equipo_index
    return cantidadPartidos
#--------------------------------------------------------------------------
def escribirIslasArchivo(islas, nuevoArchivo):
    archivo = open(nuevoArchivo,"w")
    cantidadPartidos = contarPartidos(islas)
    archivo.write(f'{cantidadEquipos} {cantidadPartidos}\n')
    for isla_index in range(len(islas)):
        for equipo_index in range(len(islas[isla_index])):
            for equipoContrario_index in range(equipo_index+1,len(islas[isla_index])):
                ganaEquipo = random.randint(0,1)
                if ganaEquipo == 1:
                    archivo.write(f'{99} {islas[isla_index][equipo_index]} {2} {islas[isla_index][equipoContrario_index]} {0}\n')
                else:
                    archivo.write(f'{99} {islas[isla_index][equipo_index]} {0} {islas[isla_index][equipoContrario_index]} {2}\n')
        archivo.write(f'\n')
    archivo.close()
#--------------------------------------------------------------------------
    
usage()
cantidadEquipos = int(sys.argv[1])
tamanoIslas = int(sys.argv[2])
cantidadIslas = int(sys.argv[3])
nuevoArchivo = sys.argv[4]
islas = separarEquiposEnIslas(cantidadEquipos, tamanoIslas, cantidadIslas)
escribirIslasArchivo(islas, nuevoArchivo)
print(islas)
