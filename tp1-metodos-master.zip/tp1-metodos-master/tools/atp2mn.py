import csv

input_path = '../atp/atp_matches_1994.csv'
output_path = '../atp/atp_matches_1994.in'

with open(input_path,'r') as csvfile,open(output_path,'w') as outfile:
        score_reader = csv.reader(csvfile,delimiter=',',skipinitialspace=True)
        # Skip the header
        next(score_reader, None)
        teams = set()
        n_games = 0
        # String with info of the games.
        out_str = ''
        fileAsList = []
        for row in score_reader:
            fileAsList.append(row)

        teams = set()
        for row in fileAsList:
            if len(row) > 6:
                teams.add(int(row[7]))
                teams.add(int(row[15]))

        teamsList = list(teams)
        teamsList.sort();
        teamsDictionary = dict()
        index = 1
        for t in teamsList:
            print(f'team in teamsList: {t} index: {index}')
            teamsDictionary[t] = index
            print(f'team in teamsDict: {teamsDictionary[t]}\n')
            index = index + 1

        for row in fileAsList:
            if len(row) > 7:
                n_games = n_games+1
                winner = teamsDictionary[int(row[7])]
                loser = teamsDictionary[int(row[15])]
                out_str = out_str + f'{row[5]} {winner} {1} {loser} {0}\n'
        # Write number of teams and games
        outfile.write(str(len(teams)) + ' ' + str(n_games) + '\n')
        # Write games details
        outfile.write(out_str)

        print("Done")
