#include<iostream>
#include<iomanip>
#include<string>
#include<fstream>
#include<vector>
#include<cmath>
#include<algorithm>

const int ancho = 4;

using namespace std;

vector<double> colleyMatrixMethod(int arr[][ancho], int alto, int equipos);

vector<double> winPercentage(int arr[][ancho], int alto, int equipos);

vector<double> alternativo(int arr[][ancho], int alto, int equipos);

void cambioFila(double *matriz, int i, int j, int tam);

void gauss(double *matriz, int tam);

double *cholesky(double *matriz, int tam);

vector<double> despejarAbajoArriba(double *matriz, int tam);

vector<double> despejarArribaAbajo (double *matriz, int tam);

double puntos(double A, double B);

int main(int argc, char *argv[]) {
    for(int i=0; i<argc;i++){                           //chequiemos si lo que estoy pasando es correcto
        cout<<"Argumento "<<i+1<<": "<<argv[i]<<"\n";
    }
    ifstream input;                                     //leemos el archivo ded entrada
    input.open(argv[1]);
    if (!input.is_open()){                              //en caso de que no se pueda leer, avisamos
        cout<<"No se pudo abrir el archivo de entrada.";
        return 1;
    }
    int cantEquipos;
    int cantPartidos;
    int fecha;
    input >> cantEquipos >> cantPartidos;               //lee la cantidad de equipos/partidos, (que son los primeros 2 elem del archivo)
    int registro[cantPartidos][ancho];
    int i=0;
    while(input >> fecha >> registro[i][0] >> registro[i][1] >> registro[i][2] >> registro[i][3]){  //voy registrando los datos que me dieron, para pasarlos a c++ y ya tenerlso aca
        i++;
    }
    input.close();                                         //dejamos de leer el archivo de entrada
    string metodo;
    vector<double> solucion;
    switch (*argv[3]){                                     //me fijo cual es el metodo que me pasan
        case '0':
            solucion=colleyMatrixMethod(registro, cantPartidos, cantEquipos);   //aca guardo la solucion dependiendo de el metodo elegido
            metodo = "Colley Matrix Method";
            break;
        case '1':
            solucion=winPercentage(registro, cantPartidos, cantEquipos);
            metodo = "Win Percentage";
            break;
        case '2':
            solucion=alternativo(registro, cantPartidos, cantEquipos);
            metodo = "Alternativo";
            break;
        default:
            cout<<"Parámetro para método de ranking desconocido. Use:\n Colley Matrix Method (CMM) \t 0\n Win Percentage (WP) \t 1\n Alternativo \t 2";
            return 3;
    }
    vector<pair<double, int> > rank;
    for(int i=0; i<solucion.size();i++){                //aca asosio el equipo con su puntaje
        rank.emplace_back(make_pair(solucion[i],i+1));  //la pos 0 es el equipo 1... la pos 1 es el equipo 2... etc
    }
    sort(rank.begin(), rank.end());             //sortea dependiendo del puntaje
    ofstream output;                        //aca empiezo a escribir el resultado
    output.open(argv[2]);                   //lo escribo al nombre que me pasaron
    if (!output.is_open()){ //si no se puede escribir....
        cout<<"No se pudo generar el archivo de salida.";
        return 2;
    }
    output<< "Ranking ("<<metodo<<"):\n";           //formato para escribir el resultado
    output<< "-------------------------------------------------------------\n";
    output<<setprecision(15);
    output<<setw(11)<<"Posición"<<setw(15)<<"Puntaje"<<setw(10)<<"Equipo"<<"\n";
    for(int i=rank.size()-1; i>=0;i--){
        output<<setw(10)<<rank.size()-i<<"º"<<setw(20)<<rank[i].first<<setw(10)<<rank[i].second<<"\n";
        output<<"----------------------------------\n";
    }
    return(0);
}

vector<double> colleyMatrixMethod(int registro[][ancho], int alto, int equipos){
    double colley[equipos][equipos+1];                              //desde aca
    for(int i=0;i<equipos;i++){
        for(int j=0; j<=equipos;j++){
            if (i==j) colley[i][j]=2.;
            else colley[i][j]=0.;
        }
    }
    for(int i=0;i<alto;i++){
        colley[registro[i][0]-1][registro[i][2]-1]--;
        colley[registro[i][2]-1][registro[i][0]-1]--;
        colley[registro[i][0]-1][registro[i][0]-1]++;
        colley[registro[i][2]-1][registro[i][2]-1]++;
        if (registro[i][1]>registro[i][3]) {
            colley[registro[i][0] - 1][equipos]++;
            colley[registro[i][2] - 1][equipos]--;
        }
        else{
            colley[registro[i][0] - 1][equipos]--;
            colley[registro[i][2] - 1][equipos]++;
        }
    }
    for (int i=0;i<equipos;i++){
        colley[i][equipos]/=2;
        colley[i][equipos]++;
    }                                                              //hasta aca, CREAMOS LA MATRIZ DE COOLEY, extendido con el resultado ("no es cuadrada")
/*
    double colleyC[equipos][equipos];
    for(int i=0;i<equipos;i++){
        for(int j=0;j<equipos;j++){
            colleyC[i][j]=colley[i][j];
        }
    }
    double *L= cholesky((double *)colleyC, equipos);
    double Lext[equipos][equipos+1];
    for(int i=0;i<equipos;i++){
        for(int j=0;j<equipos;j++){
            Lext[i][j] = L[i*equipos+j];
        }
    }
    for(int i=0;i<equipos;i++){
        Lext[i][equipos]=colley[i][equipos];
    }
    vector<double> preRes = despejarArribaAbajo((double *)Lext, equipos);
    double T[equipos][equipos+1];
    for(int i=0;i<equipos;i++){
        for(int j=0;j<equipos;j++){
            T[j][i] = L[i*equipos+j];
        }
    }
    for(int i=0;i<equipos;i++){
        T[i][equipos]=preRes[i];
    }
    vector<double> res = despejarAbajoArriba((double *)T, equipos);
*/
    gauss((double *)colley, equipos);                               //triangulo haciendo gauss
    vector<double> res = despejarAbajoArriba((double *)colley, equipos);    //despejo los resultados
    return res;
}

vector<double> winPercentage(int arr[][ancho], int alto, int equipos){
    vector<pair<int,int> > conteo (equipos,make_pair(0,0));
    for(int i=0;i<alto;i++){
        conteo[arr[i][0]-1].second++, conteo[arr[i][2]-1].second++;
        if (arr[i][1]>arr[i][3]) conteo[arr[i][0]-1].first++;
        else conteo[arr[i][2]-1].first++;
    }
    vector<double> res (equipos);
    for(int i=0;i<equipos;i++){
        res[i]=((float)conteo[i].first/(float)conteo[i].second)*100.;
    }
    return res;
}

vector<double> alternativo(int arr[][ancho], int cantPartidos, int equipos){
    //tomando un array con los puntajes tal cual nos lo pasan (sin la fecha aka el primer numerito)
    //equipos = la cantidad de equipos
    vector<double> res;                     //aca vamos a guardar la cantidad de puntos que tienen los equipos (empiezan todos en 500)
    for (int i = 0; i < equipos; ++i) {
        res.push_back(500);
    }
    for (int j = 0; j < cantPartidos; ++j) {
        int equipoA = arr[j][0]-1;
        int equipoB = arr[j][2]-1;
        double PuntajeA = arr[j][1];
        double PuntajeB = arr[j][3];
        if (res[equipoA] > res[equipoB]) { //si A tiene mas puntos
            if (PuntajeA > PuntajeB) {//si A gano
                res[equipoA] = res[equipoA] + puntos(res[equipoB], res[equipoA]);
                res[equipoB] = res[equipoB] - puntos(res[equipoB], res[equipoA]);
            } else { //si B gano
                res[equipoA] = res[equipoA] - puntos(res[equipoA], res[equipoB]);
                res[equipoB] = res[equipoB] + puntos(res[equipoA], res[equipoB]);
            }
        } else { //si B tiene mas puntos, o tienen la misma cantidad de puntos
            if (PuntajeA < PuntajeB) {//si B gano
                res[equipoA] = res[equipoA] - puntos(res[equipoB], res[equipoA]);
                res[equipoB] = res[equipoB] + puntos(res[equipoB], res[equipoA]);
            } else {  //si A gano
                res[equipoA] = res[equipoA] + puntos(res[equipoA], res[equipoB]);
                res[equipoB] = res[equipoB] - puntos(res[equipoA], res[equipoB]);
            }
        }
        if(res[equipoA]<0){     //nos encargamos que el equipo A no tenga mas puntos que 1000 ni menos que 0
            res[equipoA]=0;
        }else if(res[equipoA]>1000){
            res[equipoA]=1000;
        }
        if(res[equipoB]<0){     //nos encargamos que el equipo B no tenga mas puntos que 1000 ni menos que 0
            res[equipoB]=0;
        }else if(res[equipoB]>1000){
            res[equipoB]=1000;
        }
    }
    return res;
}

double puntos(double A, double B){
    double k = 50;
    double res = k*(abs(1 + (B-A)/1000));
    return res;

}

void cambioFila(double *matriz, int i, int j, int tam){
    for (int k=0; k<=tam; k++) {
        double temp = matriz[i*(tam+1)+k];
        matriz[i*(tam+1)+k] = matriz[j*(tam+1)+k];
        matriz[j*(tam+1)+k] = temp;
    }
}

void gauss(double *matriz, int tam){
    for (int k=0; k<tam; k++){
        int maxpivot = k;   //coordenada fila
        double maxvalor = matriz[maxpivot*(tam+1)+k];
        for (int i = k+1; i < tam; i++) {                           //me fijo cual es elnumero mas grande de la columna en la que estoy (de donde estoy hacia abajo)
            if (abs(matriz[i * (tam + 1) + k] > maxvalor)) {
                maxpivot = i;
                maxvalor = matriz[maxpivot * (tam + 1) + k];
            }
        }
        if (maxpivot != k){                                         //en caso de que encuentre un elemento mas grande, permuto las filas asi todo es mas feliz
            cambioFila(matriz, k, maxpivot, tam);
        }
        for (int i=k+1; i<tam; i++){
            double factorDif = matriz[i*(tam+1)+k] / matriz[k*(tam+1)+k];               //para cada elemento calculo el factor por el cual tengo que multifplicar el pivote para poder transformarlo en 0
            for (int j=k+1; j<=tam; j++) {                                        //le resto a las filas, la fila pivote
                matriz[i * (tam + 1) + j] -= matriz[k * (tam + 1) + j] * factorDif;
            }
            matriz[i*(tam+1)+k] = 0;
        }
    }
}

double *cholesky(double *matriz, int tam) {
    double *L = (double*)calloc(tam*tam,sizeof(double));
    if (L==NULL) exit(EXIT_FAILURE);
    for (int i=0;i<tam;i++) {
        for (int j = 0; j < (i + 1); j++) {
            double s = 0;
            for (int k = 0; k < j; k++)
                s += L[i * tam + k] * L[j * tam + k];
            L[i * tam + j] = (i == j) ? sqrt(matriz[i * tam + i] - s) : (1.0 / L[j * tam + j] * (matriz[i * tam + j] - s));
        }
    }
    return L;
}

vector<double> despejarAbajoArriba(double *matriz, int tam){
    vector<double> r(tam,0.);
    for (int i = tam-1; i >= 0; i--){
        r[i] = matriz[i*(tam+1)+tam];           //el resultado de esta fila, lo pongo en r[i]
        for (int j=i+1; j<tam; j++){
            r[i] -= matriz[i*(tam+1)+j]*r[j];   //con los resultados de mas abajo en la matriz, los resto al resultado de esta fila
        }
        r[i] /= matriz[i*(tam+1)+i];            //y dsp divido por la multiplicacion del Xi que quiero despejar, para poder obtenerlo
    }
    return r;
}

vector<double> despejarArribaAbajo(double *matriz, int tam){
    vector<double> r(tam,0.);
    for (int i = 0; i<tam; i++){
        r[i] = matriz[i*(tam+1)+tam];
        for (int j=i-1; j>=0; j--){
            r[i] -= matriz[i*(tam+1)+j]*r[j];
        }
        r[i]/= matriz[i*(tam+1)+i];
    }
    return r;
}
