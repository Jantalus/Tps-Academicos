//
// Created by Usuario on 19/06/2020.
//

#ifndef TP2_TESTS_H
#define TP2_TESTS_H

#include "../funciones.h"
#include <vector>
using namespace std;

vector<int> test_AGM_1(int& peso);
vector<int> test_AGM_2(int& peso);
vector<int> test_TABU_2(int& peso);

#endif //TP2_TESTS_H
