/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#include "screen.h"

void print(const char* text, uint32_t x, uint32_t y, uint16_t attr) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO; // magia
    int32_t i;
    for (i = 0; text[i] != 0; i++) {
        p[y][x].c = (uint8_t) text[i];
        p[y][x].a = (uint8_t) attr;
        x++;
        if (x == VIDEO_COLS) {
            x = 0;
            y++;
        }
    }
}

void print_dec(uint32_t numero, uint32_t size, uint32_t x, uint32_t y, uint16_t attr) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO; // magia
    uint32_t i;
    uint8_t letras[16] = "0123456789";

    for(i = 0; i < size; i++) {
        uint32_t resto  = numero % 10;
        numero = numero / 10;
        p[y][x + size - i - 1].c = letras[resto];
        p[y][x + size - i - 1].a = attr;
    }
}

void print_hex(uint32_t numero, int32_t size, uint32_t x, uint32_t y, uint16_t attr) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO; // magia
    int32_t i;
    uint8_t hexa[8];
    uint8_t letras[16] = "0123456789ABCDEF";
    hexa[0] = letras[ ( numero & 0x0000000F ) >> 0  ];
    hexa[1] = letras[ ( numero & 0x000000F0 ) >> 4  ];
    hexa[2] = letras[ ( numero & 0x00000F00 ) >> 8  ];
    hexa[3] = letras[ ( numero & 0x0000F000 ) >> 12 ];
    hexa[4] = letras[ ( numero & 0x000F0000 ) >> 16 ];
    hexa[5] = letras[ ( numero & 0x00F00000 ) >> 20 ];
    hexa[6] = letras[ ( numero & 0x0F000000 ) >> 24 ];
    hexa[7] = letras[ ( numero & 0xF0000000 ) >> 28 ];
    for(i = 0; i < size; i++) {
        p[y][x + size - i - 1].c = hexa[i];
        p[y][x + size - i - 1].a = attr;
    }
}

void screen_drawBox(uint32_t fInit,
                    uint32_t cInit,
                    uint32_t fSize,
                    uint32_t cSize,
                    uint8_t character,
                    uint8_t attr ) {
    ca (*p)[VIDEO_COLS] = (ca (*)[VIDEO_COLS]) VIDEO;
    uint32_t f;
    uint32_t c;
    for (f = fInit; f < fInit+fSize; f++) {
    for (c = cInit; c < cInit+cSize; c++) {
          p[f][c].c = character;
          p[f][c].a = attr;
    }}
}

void render(){
    //Imprime en pantalla los jugadores, las pelotas en pantalla, los mensajes, los puntajes, las vidas y las pelotas habilitadas
    //Usa los datos de 'game.c' para conocer esta información.
    for(uint8_t i=0; i<2; i++){
        //Como los movimientos son (a lo sumo) de a uno, solamente hace falta borrar (a lo sumo) un caracter y agregar (a lo sumo) un caracter.
        if(posJugadores[i][1]>posJugadores[i][0]){
            //Borro un caracter
            print("o", (i==0 ? 0 : 79), posJugadores[i][0] - 3, TABLE_EDGECOLOR);
            //Printeo un caracter
            print("o", (i==0 ? 0 : 79), posJugadores[i][1] + 3, (i==0 ? P1_COLOR : P2_COLOR));

        }
        else if(posJugadores[i][1]<posJugadores[i][0]){
            //Borro un caracter
            print("o", (i==0 ? 0 : 79), posJugadores[i][0] + 3, TABLE_EDGECOLOR);
            //Printeo un caracter
            print("o", (i==0 ? 0 : 79), posJugadores[i][1] - 3, (i==0 ? P1_COLOR : P2_COLOR));
        }
    }
    for(uint8_t i=0; i<2; i++){
        for(uint8_t j=0; j<3; j++){
           if(task_validez[i*3+j]==0){
                pos posPrev = posPelotas[i][j].prev;
                print("o", posPrev.x, posPrev.y-1, TABLE_COLOR);
           } 
        }
    }
    for(uint8_t i=0; i<2; i++){
        for(uint8_t j=0; j<3; j++){
           if(task_validez[i*3+j]!=0){
                pos posPrev = posPelotas[i][j].prev;
                pos posActual = posPelotas[i][j].act;
                print("o", posPrev.x, posPrev.y-1, TABLE_COLOR);
                print("o", posActual.x, posActual.y-1, (i==0 ? P1_TASK_COLOR : P2_TASK_COLOR));
           }
        }
    }

    for(uint8_t i=0; i<2; i++){
        //PRINTEAR PUNTOS, PELOTAS, VIDAS RESTANTES E INFO DE LAS PELOTAS.
        //Puntos
        print_dec((uint32_t)puntajes[0], UI_DECDIGITS, P1_PUNTAJEX, P_PUNTOSY, P1_UI_COLOR);
        print_dec((uint32_t)puntajes[1], UI_DECDIGITS, P2_PUNTAJEX, P_PUNTOSY, P2_UI_COLOR);
        //Pelotas
        print_dec((uint32_t)lives[0], UI_DECDIGITS, P1_PELOTASX, P_PELOTASY, P1_UI_COLOR);
        print_dec((uint32_t)lives[1], UI_DECDIGITS, P2_PELOTASX, P_PELOTASY, P2_UI_COLOR);

        for(uint8_t i=0; i<6; i++){
            if(task_validez[i]==1){
                //DIBUJO UN CÍRCULO PARA INDICAR QUE ESTÁ VIVA
                print("O", (i/3==0 ? P1_LIVESX : P2_LIVESX) + 2*(i%3), P_PUNTOSY, (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));
                //DIBUJO SU TIPO
                print_dec((uint32_t)(i%3), 1, (i/3==0 ? P1_INTERFAZX : P2_INTERFAZX), P_TASK1Y + (i%3), (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));
                print(":Tarea ", (i/3==0 ? P1_INTERFAZX : P2_INTERFAZX) + 1, P_TASK1Y + (i%3), (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));
                print((i/3==0 ? "A" : "B"), (i/3==0 ? P1_INTERFAZX : P2_INTERFAZX) + UI_LETTEROFFSET, P_TASK1Y + (i%3), (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));
                print_dec((uint32_t)tipoPelotas[i/3][i%3], 1, (i/3==0 ? P1_INTERFAZX : P2_INTERFAZX) + UI_LETTEROFFSET + 1, P_TASK1Y + (i%3), (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));

                //SI TIENE MENSAJE, LO IMPRIMO
                if(msgs[i/3][i%3]!=0){
                    print(UI_MSGFILLERTEXT, (i/3==0 ? P1_INTERFAZX : P2_INTERFAZX)+12, P_TASK1Y + (i%3), (i/3==0 ? P1_COLOR : P2_COLOR));
                    print((char*)msgs[i/3][i%3], (i/3==0 ? P1_MSGX : P2_MSGX), P_TASK1Y + (i%3), (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));
                }
            }
            else{
                //DIBUJO UNA CRUZ PARA INDICAR QUE ESTÁ MUERTA
                print("X", (i/3==0 ? P1_LIVESX : P2_LIVESX) + 2*(i%3), P_PUNTOSY, (i/3==0 ? P1_UI_COLOR : P2_UI_COLOR));
                //BORRO SU TIPO Y SU MENSAJE
                print(UI_FILLERTEXT, (i/3==0 ? P1_INTERFAZX : P2_INTERFAZX), P_TASK1Y + (i%3), (i/3==0 ? P1_COLOR : P2_COLOR));
            }
        }
    }

}

void printDebug(uint32_t* ptr_esp, uint8_t num){
    uint8_t hayErrCode = (num>=10 && num<=14 ? 1 : 0);
    uint16_t* VIDEO_BUFFER = (uint16_t*) VIDEO;
    for(uint32_t i=0; i<DEBUG_BUFFERSIZE; i++){
        buffer[i] = VIDEO_BUFFER[i];
    }
    uint32_t edi = ptr_esp[1];
    uint32_t esi = ptr_esp[2];
    uint32_t ebp = ptr_esp[3];
    uint32_t esp = ptr_esp[12+hayErrCode];
    uint32_t ebx = ptr_esp[5];
    uint32_t edx = ptr_esp[6];
    uint32_t ecx = ptr_esp[7];
    uint32_t eax = ptr_esp[8];
    uint32_t eip = ptr_esp[9+hayErrCode];
    uint32_t cs = ptr_esp[10+hayErrCode];
    uint32_t eflags = ptr_esp[11+hayErrCode];
    uint32_t ss = ptr_esp[13+hayErrCode];
    //temporal
    uint32_t ds = rds();
    uint32_t es = res();
    uint32_t fs = rfs();
    uint32_t gs = rgs();
    uint32_t cr0 = rcr0();
    uint32_t cr2 = rcr2();
    uint32_t cr3 = rcr3();
    uint32_t cr4 = rcr4();

    uint32_t stack[5];
    uint32_t* ptr_userstack = (uint32_t*) esp;
    for(uint8_t i=0; i<5; i++){
        stack[i] = ptr_userstack[i];
    }
    screen_drawBox(1, 30, 39, 30, 'O', COLOR_NEGRO);
    screen_drawBox(4, 31, 36, 28, 'O', TABLE_COLOR);
    screen_drawBox(2, 31, 1, 28, 'O', COLOR_AMARILLO);
    print_dec(num, 2, 31, 2, COLOR_ROJOYAMARILLO);

    switch(num){
        case 0:
            print("Divide Error", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 1:
            print("RESERVED", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 2:
            print("NMI Interrupt", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 3:
            print("Breakpoint", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 4:
            print("Overflow", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 5:
            print("BOUND Range Exceeded", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 6:
            print("Invalid Opcode", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 7:
            print("Device Not Available", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 8:
            print("Double Fault", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 9:
            print("Coprocessor Segment Overrun", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 10:
            print("Invalid TSS", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 11:
            print("Segment Not Present", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 12:
            print("Stack Segment Fault", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 13:
            print("General Protection", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 14:
            print("Page Fault", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 15:
            print("RESERVED", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 16:
            print("FPU Error", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 17:
            print("Alignment Check", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 18:
            print("Machine Check", 34, 2, COLOR_ROJOYAMARILLO);
            break;
        case 19:
            print("SIMD Exception", 34, 2, COLOR_ROJOYAMARILLO);
            break;
    }

    //Nombres de los registros
    print("EAX", 32, 5, COLOR_NEGROYGRIS);
    print("EBX", 32, 7, COLOR_NEGROYGRIS);
    print("ECX", 32, 9, COLOR_NEGROYGRIS);
    print("EDX", 32, 11, COLOR_NEGROYGRIS);
    print("ESI", 32, 13, COLOR_NEGROYGRIS);
    print("EDI", 32, 15, COLOR_NEGROYGRIS);
    print("EBP", 32, 17, COLOR_NEGROYGRIS);
    print("ESP", 32, 19, COLOR_NEGROYGRIS);
    print("EIP", 32, 21, COLOR_NEGROYGRIS);
    print("CS", 32, 23,COLOR_NEGROYGRIS);
    print("DS", 32, 25,COLOR_NEGROYGRIS);
    print("ES", 32, 27,COLOR_NEGROYGRIS);
    print("FS", 32, 29,COLOR_NEGROYGRIS);
    print("GS", 32, 31,COLOR_NEGROYGRIS);
    print("SS", 32, 33,COLOR_NEGROYGRIS);
    print("EFLAGS", 32, 36, COLOR_NEGROYGRIS);

    print("CR0", 46, 6, COLOR_NEGROYGRIS);
    print("CR2", 46, 8, COLOR_NEGROYGRIS);
    print("CR3", 46, 10, COLOR_NEGROYGRIS);
    print("CR4", 46, 12, COLOR_NEGROYGRIS);

    print("STACK", 46, 26, COLOR_NEGROYGRIS);

    //Valores de los registros
    print_hex(eax, 8, 36, 5, COLOR_BLANCOYGRIS);
    print_hex(ebx, 8, 36, 7, COLOR_BLANCOYGRIS);
    print_hex(ecx, 8, 36, 9, COLOR_BLANCOYGRIS);
    print_hex(edx, 8, 36, 11, COLOR_BLANCOYGRIS);
    print_hex(esi, 8, 36, 13, COLOR_BLANCOYGRIS);
    print_hex(edi, 8, 36, 15, COLOR_BLANCOYGRIS);
    print_hex(ebp, 8, 36, 17, COLOR_BLANCOYGRIS);
    print_hex(esp, 8, 36, 19, COLOR_BLANCOYGRIS);
    print_hex(eip, 8, 36, 21, COLOR_BLANCOYGRIS);
    print_hex(cs, 4, 36, 23,COLOR_BLANCOYGRIS);
    print_hex(ds, 4, 36, 25,COLOR_BLANCOYGRIS);
    print_hex(es, 4, 36, 27,COLOR_BLANCOYGRIS);
    print_hex(fs, 4, 36, 29,COLOR_BLANCOYGRIS);
    print_hex(gs, 4, 36, 31,COLOR_BLANCOYGRIS);
    print_hex(ss, 4, 36, 33,COLOR_BLANCOYGRIS);

    print_dec(eflags, 11, 39, 36, COLOR_BLANCOYGRIS);

    print_hex(cr0, 8, 50, 6, COLOR_BLANCOYGRIS);
    print_hex(cr2, 8, 50, 8, COLOR_BLANCOYGRIS);
    print_hex(cr3, 8, 50, 10, COLOR_BLANCOYGRIS);
    print_hex(cr4, 8, 50, 12, COLOR_BLANCOYGRIS);

    print_hex(stack[0], 8, 46, 28,COLOR_BLANCOYGRIS);
    print_hex(stack[1], 8, 46, 29,COLOR_BLANCOYGRIS);
    print_hex(stack[2], 8, 46, 30,COLOR_BLANCOYGRIS);
    print_hex(stack[3], 8, 46, 31,COLOR_BLANCOYGRIS);
    print_hex(stack[4], 8, 46, 32,COLOR_BLANCOYGRIS);

    return;
}

void cleanDebug(){
    uint16_t* VIDEO_BUFFER = (uint16_t*) VIDEO;
    for(uint32_t i=0; i<DEBUG_BUFFERSIZE; i++){
        VIDEO_BUFFER[i] = buffer[i];
    }
    return;
}

void renderFin(){
    screen_drawBox(15, 28, 10, 24, 'O', (puntajes[0]>puntajes[1] ? P1_COLOR : (puntajes[0]==puntajes[1] ? COLOR_GRISOSCURO : P2_COLOR)));
    print("Fin", 39, 18, (puntajes[0]>puntajes[1] ? P1_UI_COLOR : (puntajes[0]==puntajes[1] ? COLOR_BLANCOYGRISOSCURO : P2_UI_COLOR)));
    print((puntajes[0]>puntajes[1] ? "Equipo Rojo gana!" : (puntajes[0]==puntajes[1] ? "Empate!" : "Equipo Azul gana!")), (puntajes[0]>puntajes[1] ? 32 : (puntajes[0]==puntajes[1] ? 37 : 32)), 21, (puntajes[0]>puntajes[1] ? P1_UI_COLOR : (puntajes[0]==puntajes[1] ? COLOR_BLANCOYGRISOSCURO : P2_UI_COLOR)));
}

