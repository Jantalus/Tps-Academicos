/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
*/

#include "syscall.h" 

void handler(void);

void task() {
    char* message = "Tarea A1";
    syscall_talk(message);
    syscall_setHandler(handler);
	uint32_t* kernel_ptr = (uint32_t*) 0x0000DEAD;
	*kernel_ptr = 0xDEADDEAD;

    while(1) { __asm __volatile("mov $1, %%eax":::"eax"); }
}

void handler() {
	syscall_informAction(Center);
}
