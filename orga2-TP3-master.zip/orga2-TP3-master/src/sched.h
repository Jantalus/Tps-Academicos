/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#ifndef __SCHED_H__
#define __SCHED_H__

#include "stdint.h"
#include "screen.h"
#include "tss.h"
#include "game.h"			//HICIMOS ESTE INCLUDE PARA PODER LLAMAR A ACT()

void sched_init();

uint16_t sched_nextTask();

void desalojarTareaYHandler();

uint8_t ciclo;						//El valor de este número entero dicta la tarea a ejecutar.
uint8_t esHandler;					//Indica si la tarea que fue interrumpida es un handler.


#endif	/* !__SCHED_H__ */
