/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de la tabla de descriptores globales
*/

#include "gdt.h"

gdt_entry gdt[GDT_COUNT] = {
    /* Descriptor nulo*/
    /* Offset = 0x00 */
    [GDT_IDX_NULL_DESC] = (gdt_entry) {0},
    [GDT_IDX_CODIGO_NIVEL0] = (gdt_entry) {
        (uint16_t)    DIR_150((163<<8)-1),      /* limit[0:15]  */
        (uint16_t)    DIR_150(DIR_ZERO),        /* base[0:15]   */
        (uint8_t)     DIR_2316(DIR_ZERO),       /* base[23:16]  */
        (uint8_t)     0xA,                      /* type         */  //Código, ejecución y lectura
        (uint8_t)     S_CODEDATA,               /* s            */
        (uint8_t)     DPL_KERNEL,               /* dpl          */
        (uint8_t)     PRESENT_ON,               /* p            */
        (uint8_t)     DIR_1916((163<<8)-1),     /* limit[16:19] */
        (uint8_t)     AVL_0,                    /* avl          */
        (uint8_t)     L_32b,                    /* l            */
        (uint8_t)     DB_32b,                   /* db           */
        (uint8_t)     GRANULARITY_PAGE,         /* g            */
        (uint8_t)     DIR_3124(DIR_ZERO),       /* base[31:24]  */
    },
    [GDT_IDX_CODIGO_NIVEL3] = (gdt_entry) {
        (uint16_t)    DIR_150((163<<8)-1),      /* limit[0:15]  */
        (uint16_t)    DIR_150(DIR_ZERO),        /* base[0:15]   */
        (uint8_t)     DIR_2316(DIR_ZERO),       /* base[23:16]  */
        (uint8_t)     0xA,                      /* type         */  //Código, ejecución y lectura
        (uint8_t)     S_CODEDATA,               /* s            */
        (uint8_t)     DPL_USER,                 /* dpl          */
        (uint8_t)     PRESENT_ON,               /* p            */
        (uint8_t)     DIR_1916((163<<8)-1),     /* limit[16:19] */
        (uint8_t)     AVL_0,                    /* avl          */
        (uint8_t)     L_32b,                    /* l            */
        (uint8_t)     DB_32b,                   /* db           */
        (uint8_t)     GRANULARITY_PAGE,         /* g            */
        (uint8_t)     DIR_3124(DIR_ZERO),       /* base[31:24]  */
    },
    [GDT_IDX_DATOS_NIVEL0] = (gdt_entry) {
        (uint16_t)    DIR_150((163<<8)-1),      /* limit[0:15]  */
        (uint16_t)    DIR_150(DIR_ZERO),        /* base[0:15]   */
        (uint8_t)     DIR_2316(DIR_ZERO),       /* base[23:16]  */
        (uint8_t)     0x2,                      /* type         */  //Datos, lectura y escritura
        (uint8_t)     S_CODEDATA,               /* s            */
        (uint8_t)     DPL_KERNEL,               /* dpl          */
        (uint8_t)     PRESENT_ON,               /* p            */
        (uint8_t)     DIR_1916((163<<8)-1),     /* limit[16:19] */
        (uint8_t)     AVL_0,                    /* avl          */
        (uint8_t)     L_32b,                    /* l            */
        (uint8_t)     DB_32b,                   /* db           */
        (uint8_t)     GRANULARITY_PAGE,         /* g            */
        (uint8_t)     DIR_3124(DIR_ZERO),       /* base[31:24]  */
    },
    [GDT_IDX_DATOS_NIVEL3] = (gdt_entry) {
        (uint16_t)    DIR_150((163<<8)-1),      /* limit[0:15]  */
        (uint16_t)    DIR_150(DIR_ZERO),        /* base[0:15]   */
        (uint8_t)     DIR_2316(DIR_ZERO),       /* base[23:16]  */
        (uint8_t)     0x2,                      /* type         */  //Datos, lectura y escritura
        (uint8_t)     S_CODEDATA,               /* s            */
        (uint8_t)     DPL_USER,                 /* dpl          */
        (uint8_t)     PRESENT_ON,               /* p            */
        (uint8_t)     DIR_1916((163<<8)-1),     /* limit[16:19] */
        (uint8_t)     AVL_0,                    /* avl          */
        (uint8_t)     L_32b,                    /* l            */
        (uint8_t)     DB_32b,                   /* db           */
        (uint8_t)     GRANULARITY_PAGE,         /* g            */
        (uint8_t)     DIR_3124(DIR_ZERO),       /* base[31:24]  */
    },
    [GDT_IDX_SCREEN_BUFFER] = (gdt_entry) {
        (uint16_t)    DIR_150(VIDEO_SIZE-1),    /* limit[0:15]  */
        (uint16_t)    DIR_150(VIDEO),  /* base[0:15]   */
        (uint8_t)     DIR_2316(VIDEO), /* base[23:16]  */
        (uint8_t)     0x02,                     /* type         */  //Datos, lectura y escritura
        (uint8_t)     S_CODEDATA,               /* s            */
        (uint8_t)     DPL_KERNEL,               /* dpl          */
        (uint8_t)     PRESENT_ON,               /* p            */
        (uint8_t)     DIR_1916(VIDEO_SIZE-1),   /* limit[16:19] */
        (uint8_t)     AVL_0,                    /* avl          */
        (uint8_t)     L_32b,                    /* l            */
        (uint8_t)     DB_32b,                   /* db           */
        (uint8_t)     GRANULARITY_PAGE,         /* g            */
        (uint8_t)     DIR_3124(VIDEO), /* base[31:24]  */
    },
    [GDT_IDX_TSS_INITIAL] = (gdt_entry) {0},          //Empieza nula porque no sabemos de antemano dónde va a caer tss_initial, porque todavía no está definida.
    [GDT_IDX_TSS_IDLE] = (gdt_entry) {0},             //Empieza nula porque no sabemos de antemano dónde va a caer tss_idle, porque todavía no está definida.
    [GDT_IDX_TSS_A1_t] = (gdt_entry) {0},
    [GDT_IDX_TSS_A1_h] = (gdt_entry) {0},
    [GDT_IDX_TSS_A2_t] = (gdt_entry) {0},
    [GDT_IDX_TSS_A2_h] = (gdt_entry) {0},
    [GDT_IDX_TSS_A3_t] = (gdt_entry) {0},
    [GDT_IDX_TSS_A3_h] = (gdt_entry) {0},
    [GDT_IDX_TSS_B1_t] = (gdt_entry) {0},
    [GDT_IDX_TSS_B1_h] = (gdt_entry) {0},
    [GDT_IDX_TSS_B2_t] = (gdt_entry) {0},
    [GDT_IDX_TSS_B2_h] = (gdt_entry) {0},
    [GDT_IDX_TSS_B3_t] = (gdt_entry) {0},
    [GDT_IDX_TSS_B3_h] = (gdt_entry) {0},     
};

gdt_descriptor GDT_DESC = {
    sizeof(gdt) - 1,
    (uint32_t) &gdt
};