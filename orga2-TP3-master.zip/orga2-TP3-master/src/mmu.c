/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del manejador de memoria
*/
#include "mmu.h"

unsigned int proxima_pagina_libre_kernel;
unsigned int proxima_pagina_libre_task;

pte* mmu_tableInit(){
    pte* new_table = (pte*)(mmu_nextFreeKernelPage());
    for (int i = 0; i < KERNEL_SIZE_TABLE; ++i){
        new_table[i] = (pte) {0};
    }
    return new_table;
}

void mapCopyUnmap(uint32_t page, uint32_t task_dir){
    mmu_mapPage(page, rcr3(), page, RWUser);
    int* task_a_copiar = (int*)task_dir;
    int* page_a_copiar = (int*)page;
    for (int i = 0; i < (PAG_SIZE/4); ++i){
        page_a_copiar[i] = task_a_copiar[i];
    }
    mmu_unmapPage(page, rcr3());
    return;
}

void mmu_init() {
    proxima_pagina_libre_kernel = INICIO_PAGINAS_LIBRES_KERNEL;
    proxima_pagina_libre_task = INICIO_PAGINAS_LIBRES_TASK;
}

uint32_t mmu_nextFreeKernelPage() {
    unsigned int pagina_libre = proxima_pagina_libre_kernel;
    proxima_pagina_libre_kernel += PAG_SIZE;
    return pagina_libre;
}

uint32_t mmu_nextFreeTaskPage() {
    unsigned int pagina_libre = proxima_pagina_libre_task;
    proxima_pagina_libre_task += PAG_SIZE;
    return pagina_libre;
}

void mmu_mapPage(uint32_t virtual, uint32_t cr3, uint32_t phy, pt_attrs attrs) {
    pde* dir_ptr = (pde*)((cr3>>12)<<12);
    unsigned int pd_index = virtual >> 22;
    unsigned int pt_index = (virtual << 10) >> 22;

    pde* pde_ptr = &dir_ptr[pd_index];
    pte* pte_ptr;
    if(!(pde_ptr)->p){
        pte_ptr = mmu_tableInit();                                               //nos encargamos de crear la nueva page table
        pde_ptr->baseTable = ((int)pte_ptr>>12);                                           //metemos el puntero de la nueva page table en la page directory
        pde_ptr->p = 1;
        pde_ptr->us = 1;
        pde_ptr->rw = 1;
    }
    else{
        pte_ptr = (pte*)(pde_ptr->baseTable<<12);
    }
    pte_ptr[pt_index].p = 1;
    pte_ptr[pt_index].basePage = phy >> 12;
    pte_ptr[pt_index].rw = (attrs==RUser || attrs==RSupervisor ? 0 : 1);
    pte_ptr[pt_index].us = (attrs==RSupervisor || attrs==RWSupervisor ? 0 : 1);

    
    tlbflush();
    return;
}

uint32_t mmu_unmapPage(uint32_t virtual, uint32_t cr3) {
    pde* dir_ptr = (pde*)((cr3>>12)<<12);
    unsigned int pd_index = virtual >> 22;
    unsigned int pt_index = (virtual << 10) >> 22;
    pde* pde_ptr = &dir_ptr[pd_index];
    if((pde_ptr)->p){
        pte* pte_ptr = (pte*)(pde_ptr->baseTable<<12);
        pte_ptr[pt_index].p = 0;
    }
    tlbflush();
    return 0;
}

uint32_t mmu_initKernelDir() {
	//Inicializamos el directorio de páginas.
	pde* dir = (pde*) (KERNEL_PAGE_DIR);
	for (int i = 0; i < KERNEL_SIZE_DIRECTORY; ++i){
		dir[i]= (pde) {0};
	}
	dir[0].p = 1;
    dir[0].rw = 1;
    dir[0].us = 0;
    dir[0].pwt = 0;
    dir[0].pcd = 0;
    dir[0].a = 0;
    dir[0].cero = 0;
    dir[0].ps = 0;
    dir[0].g = 0;
    dir[0].avl = 0;
    dir[0].baseTable = (KERNEL_PAGE_TABLE_0 >> 12);


    //Inicializamos la única tabla de páginas que habrá en nuestro directorio de páginas.
    pte* table = (pte*) (dir[0].baseTable << 12);

    for (int i = 0; i < KERNEL_SIZE_TABLE; ++i){
    	table[i].p = 1;
    	table[i].rw = 1;
    	table[i].us = 0;
    	table[i].pwt = 0;
    	table[i].pcd = 0;
    	table[i].a = 0;
    	table[i].d = 0;
    	table[i].ps = 0;
    	table[i].g = 0;
    	table[i].avl = 0;
    	table[i].basePage = i;
    }

    return 0; //fin
}

uint32_t mmu_initTaskDir(uint32_t task_dir) {
    uint32_t dir_ptr = mmu_nextFreeKernelPage();
    //Inicializamos el directorio de páginas.

    for (int i = 0; i < 1024; ++i){
        mmu_mapPage(i<<12, dir_ptr, i<<12, RWSupervisor);
    }

    uint32_t task_pag1 = mmu_nextFreeTaskPage();
    uint32_t task_pag2 = mmu_nextFreeTaskPage();

    int idx = (task_dir-TASK_A1_PHYS)/(2*PAG_SIZE);                                //Guardamos las direcciones físicas de las tareas para cuando tengamos que pisar este código más tarde al llamar mapCopyUnmap, cuando se creen otras tareas.
    task_phys[idx] = task_pag1;

    mapCopyUnmap(task_pag1, task_dir);
    task_dir += PAG_SIZE;
    mapCopyUnmap(task_pag2, task_dir);
    

    mmu_mapPage(VIRTUAL_ADDRESS_TASK, dir_ptr, task_pag1, RWUser);
    mmu_mapPage(VIRTUAL_ADDRESS_TASK + PAG_SIZE, dir_ptr, task_pag2, RWUser);
    return dir_ptr; //fin
}