/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
*/

#ifndef __GAME_H__
#define __GAME_H__

#include "stdint.h"
#include "defines.h"
#include "screen.h"
#include "mmu.h"
#include "sched.h"

typedef void (*f_handler_t)();

typedef enum e_action {
    Up = 1,
    Center = 2,
    Down = 3,
} e_action_t;

void game_init();

void act();

void crearTasks();

void resetearTeclasMov();

void registrarTecla(uint8_t tecla);

void sys_talk(char* m);
uint8_t sys_setHandler(f_handler_t* f);
uint16_t sys_informAction(e_action_t action);
uint32_t sys_wherex();
uint32_t sys_wherey();

void loopFin();

typedef struct pos {
    uint32_t x;
    uint32_t y;
} pos;

typedef struct pairPos {
    pos prev;
    pos act;
} pairPos;

typedef struct pairBool {
    uint8_t x;
    uint8_t y;
} pairBool;


uint8_t posJugadores[2][2];	//Acá se almacenan las posiciones anteriores y actuales de cada jugador.
e_action_t acciones[2][3];	//Acá se almacenan las intenciones de las pelotas.
uint8_t lives[2];			//Acá se almacena la cantidad de pelotas restantes de cada jugador.
uint8_t puntajes[2];		//Acá se almacena el puntaje de cada jugador.
uint8_t pelotasLanzadas[2];	//Es un buffer de las pelotas que quieren tirar los jugadores; se revisa en el ciclo 6 del juego.
int8_t movJugadores[2];		//Es un buffer de las intenciones de movimiento de los jugadores.	
pairPos posPelotas[2][3];	//Acá se almacenan las posiciones anteriores y actuales, para las 6 pelotas (máximo).
pairBool refPelotas[2][3];	//Acá se almacenan valores booleanos para cada pelota, que definen la interpretación de sus movimientos.
uint8_t tipoPelotas[2][3];	//Acá se almacena el tipo de cada pelota de cada jugador: 1 = 'A', 2 = 'B', 3 = 'C'.
char msgs[2][3][20];		//Es un buffer para los mensajes de las tres pelotas de cada jugador.
uint8_t debugMode;			//Valor booleano que indica si está activado o no el modo debug
uint8_t debugFreeze;		//Valor booleano que indica si el juego se encuentra detenido porque cayó una excepción con modo debug activado

#endif  /* !__GAME_H__ */
