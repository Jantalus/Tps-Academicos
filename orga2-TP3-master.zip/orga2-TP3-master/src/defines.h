/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================

    Definiciones globales del sistema.
*/

#ifndef __DEFINES_H__
#define __DEFINES_H__

/* Macros */
/* -------------------------------------------------------------------------- */

/* Bool */
/* -------------------------------------------------------------------------- */
#define TRUE                    0x00000001
#define FALSE                   0x00000000
#define ERROR                   1

/* Atributos paginas */
/* -------------------------------------------------------------------------- */
#define PAG_P                   0x00000001
#define PAG_R                   0x00000000
#define PAG_RW                  0x00000002
#define PAG_S                   0x00000000
#define PAG_US                  0x00000004
#define PAG_SIZE				0x00001000

/* Misc */
/* -------------------------------------------------------------------------- */
#define DIR_ZERO				0x00000000
#define IDTATTR_DPL3			0xEE00					
#define EFLAGS_INTERRUPTENABLE	0x202

/* Campos de descriptor de gdt */
/* -------------------------------------------------------------------------- */
#define GRANULARITY_BYTE 		0x0
#define GRANULARITY_PAGE		0x1
#define DB_16b 					0x0
#define DB_32b 					0x1
#define L_32b					0x0
#define L_64b					0x1
#define AVL_0					0x0
#define PRESENT_ON				0x1
#define PRESENT_OFF				0x0
#define DPL_KERNEL				0x0
#define DPL_SERVICE1			0x1
#define DPL_SERVICE2			0x2
#define DPL_USER				0x3
#define S_SYSTEM				0x0
#define S_CODEDATA				0x1
#define DIR_150(dir) ((dir) & (0x0000FFFF))
#define DIR_2316(dir) ((dir >> 16) & (0x000000FF))
#define DIR_3124(dir) (dir >> 24)
#define DIR_1916(dir) (((dir) >> 16) & (0x0000000F))

/* Indices en la gdt */
/* -------------------------------------------------------------------------- */
#define GDT_COUNT 33

#define GDT_IDX_NULL_DESC           0
//[13 ENTRADAS RESERVADAS]
#define GDT_IDX_CODIGO_NIVEL0		14
#define GDT_IDX_CODIGO_NIVEL3		15
#define GDT_IDX_DATOS_NIVEL0		16
#define GDT_IDX_DATOS_NIVEL3		17
#define GDT_IDX_SCREEN_BUFFER		18
#define GDT_IDX_TSS_INITIAL			19
#define GDT_IDX_TSS_IDLE			20
#define GDT_IDX_TSS_A1_t			21
#define GDT_IDX_TSS_A1_h			22
#define GDT_IDX_TSS_A2_t			23
#define GDT_IDX_TSS_A2_h			24
#define GDT_IDX_TSS_A3_t			25
#define GDT_IDX_TSS_A3_h			26
#define GDT_IDX_TSS_B1_t			27
#define GDT_IDX_TSS_B1_h			28
#define GDT_IDX_TSS_B2_t			29
#define GDT_IDX_TSS_B2_h			30
#define GDT_IDX_TSS_B3_t			31
#define GDT_IDX_TSS_B3_h			32

/* Offsets en la gdt */
/* -------------------------------------------------------------------------- */
#define GDT_OFF_NULL_DESC           (GDT_IDX_NULL_DESC << 3)
//[13 ENTRADAS RESERVADAS]
#define GDT_OFF_CODIGO_NIVEL0		(GDT_IDX_CODIGO_NIVEL0 << 3)
#define GDT_OFF_CODIGO_NIVEL3		(GDT_IDX_CODIGO_NIVEL3 << 3)
#define GDT_OFF_DATOS_NIVEL0		(GDT_IDX_DATOS_NIVEL0 << 3)
#define GDT_OFF_DATOS_NIVEL3		(GDT_IDX_DATOS_NIVEL3 << 3)
#define GDT_OFF_SCREEN_BUFFER		(GDT_IDX_SCREEN_BUFFER << 3)

/* Selectores de segmentos */
/* -------------------------------------------------------------------------- */
#define GDT_SEL_CODIGO_NIVEL0		(GDT_IDX_CODIGO_NIVEL0 << 3)
#define GDT_SEL_CODIGO_NIVEL3		((GDT_IDX_CODIGO_NIVEL3 << 3) | 3)
#define GDT_SEL_DATOS_NIVEL0		(GDT_IDX_DATOS_NIVEL0 << 3)
#define GDT_SEL_DATOS_NIVEL3		((GDT_IDX_DATOS_NIVEL3 << 3) | 3)

/* Direcciones de memoria */
/* -------------------------------------------------------------------------- */
#define BOOTSECTOR               0x00001000 /* direccion fisica de comienzo del bootsector (copiado) */
#define KERNEL                   0x00001200 /* direccion fisica de comienzo del kernel */
#define VIDEO           		 0x000B8000 /* direccion fisica del buffer de video */
#define VIDEO_SIZE				 0x00008000 /* tamaño del buffer de video */

/* Direcciones virtuales de código, pila y datos */
/* -------------------------------------------------------------------------- */
#define TASK_CODE             0x08000000 /* direccion virtual del codigo */

/* Direcciones fisicas de codigos */
/* -------------------------------------------------------------------------- */
#define TASK_PHYS 				 0x00010000	
#define TASK_A1_PHYS             0x00010000 /* direccion física del codigo */
#define TASK_A2_PHYS             0x00012000 /* direccion física del codigo */
#define TASK_A3_PHYS             0x00014000 /* direccion física del codigo */
#define TASK_B1_PHYS             0x00016000 /* direccion física del codigo */
#define TASK_B2_PHYS             0x00018000 /* direccion física del codigo */
#define TASK_B3_PHYS             0x0001A000 /* direccion física del codigo */
#define TASK_IDLE_PHYS           0x0001C000 /* direccion física del codigo */


/* En estas direcciones estan los códigos de todas las tareas. De aqui se
 * copiaran al destino indicado por TASK_<i>_CODE_ADDR.
 */

/* Direcciones fisicas de directorios y tablas de paginas del KERNEL */
/* -------------------------------------------------------------------------- */
#define KERNEL_PAGE_DIR          0x0002B000
#define KERNEL_PAGE_TABLE_0      0x0002C000
#define KERNEL_SIZE_DIRECTORY    1024
#define KERNEL_SIZE_TABLE		 1024

#define TASK_SIZE_DIRECTORY    	 1024
#define TASK_SIZE_TABLE		 	 1024
#define VIRTUAL_ADDRESS_TASK	 0x08000000


/* Direcciones fisicas de próxima página libre*/
/* -------------------------------------------------------------------------- */
#define INICIO_PAGINAS_LIBRES_KERNEL 0x100000
#define INICIO_PAGINAS_LIBRES_TASK 0x400000

/* Direcciones fisicas de TSS*/
/* -------------------------------------------------------------------------- */
#define TSS_SIZE			0x00068
#define TSS_IDLE_DIR		0x1C000

/* Enums*/
/* -------------------------------------------------------------------------- */
typedef enum pt_attrs {RUser, RSupervisor, RWUser, RWSupervisor} pt_attrs;
typedef enum tasktype {A1=0, A2, A3, B1, B2, B3} tasktype;
typedef enum clase {isTask=0, isHandler} clase;

/* Constantes de la interfaz gráfica*/
/* -------------------------------------------------------------------------- */
//Constantes del juego
#define P_LENGTH 		7
//Posiciones límite
#define X_LIM			79
#define Y_LIM			39
//Posiciones iniciales
#define P1_INIT_X		0
#define P1_INIT_Y		20
#define P2_INIT_X		79
#define P2_INIT_Y		20
#define P1_COLOR		0xCC		
#define P2_COLOR		0x99
#define P1_TASK_COLOR	0x7C
#define P2_TASK_COLOR	0x79
#define P1_UI_COLOR		0xCF
#define P2_UI_COLOR		0x9F
#define TABLE_COLOR		0x77
#define TABLE_EDGECOLOR	0xFF
#define COLOR_NEGRO		0x00
#define COLOR_GRISOSCURO	0x88
#define COLOR_BLANCOYGRISOSCURO	0x8F
#define COLOR_BLANCOYNEGRO	0x0F
#define COLOR_NEGROYGRIS	0x70
#define COLOR_BLANCOYGRIS	0x7F
#define COLOR_AMARILLO	0xEE
#define COLOR_ROJOYAMARILLO	0xE4
#define P1_TASK_INITX	1
#define P2_TASK_INITX	78
#define P_LIMINF		3
#define P_LIMSUP		36
#define MSG_SIZE		20

#define P1_INTERFAZX	2
#define P1_PUNTAJEX		P1_INTERFAZX + 8
#define P1_PELOTASX		P1_INTERFAZX + 9
#define P1_LIVESX		16
#define P1_MSGX			P1_INTERFAZX + 11	

#define P2_INTERFAZX	42
#define P2_PUNTAJEX		P2_INTERFAZX + 8
#define P2_PELOTASX		P2_INTERFAZX + 9
#define P2_LIVESX		56
#define P2_MSGX			P2_INTERFAZX + 11	

#define SCANCODE_W		0x11
#define SCANCODE_S		0x1F

#define SCANCODE_Z		0x2C
#define SCANCODE_X		0x2D
#define SCANCODE_C		0x2E

#define SCANCODE_I		0x17
#define SCANCODE_K		0x25

#define SCANCODE_B		0x30
#define SCANCODE_N		0x31
#define SCANCODE_M		0x32

#define SCANCODE_Y		0x15

#define P_PUNTOSY		42
#define P_PELOTASY		43
#define P_TASK1Y		45
#define P_TASK2Y		46
#define P_TASK3Y		47
#define UI_LETTEROFFSET	8
#define UI_DECDIGITS	2
#define UI_FILLERTEXT	"XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX"
#define UI_MSGFILLERTEXT "XXXXXXXXXXXXXXXXXXX"


#define DEBUG_BUFFERSIZE	4000

#endif  /* !__DEFINES_H__ */