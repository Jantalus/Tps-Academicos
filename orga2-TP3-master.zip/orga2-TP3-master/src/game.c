/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
*/

#include "game.h"

void game_init() {
    for(uint8_t i=0; i<6; i++){
        task_validez[i]=0;
    }
    posJugadores[0][0]=P1_INIT_Y;
    posJugadores[0][1]=P1_INIT_Y;
    posJugadores[1][0]=P2_INIT_Y;
    posJugadores[1][1]=P2_INIT_Y;
	lives[0] = 15;
    lives[1] = 15;
    puntajes[0] = 0;
    puntajes[1] = 0;
    pelotasLanzadas[0] = 0;
    pelotasLanzadas[1] = 0;
    movJugadores[0] = 0;
    movJugadores[1] = 0;
    for(uint8_t i=0; i<2; i++){
        for(uint8_t j=0; j<3; j++){
            for(uint8_t k=0; k<MSG_SIZE; k++){
                msgs[i][j][k]=0;
            }
            posPelotas[i][j].prev.x = 10;
            posPelotas[i][j].prev.y = 10;
            posPelotas[i][j].act.x = 10;
            posPelotas[i][j].act.y = 10;
            refPelotas[i][j].x = 0;
            refPelotas[i][j].y = 0;
            tipoPelotas[i][j] = 0;
        }
    }
    for(uint8_t i=0; i<7; i++){
        print("o",P1_INIT_X,posJugadores[0][1]-3+i, P1_COLOR);
        print("o",P2_INIT_X,posJugadores[0][1]-3+i, P2_COLOR);
    }
    debugMode = 0;
    debugFreeze = 0;
}

void act(){
    //HAY QUE PONER UN IF ACÁ PARA VERIFICAR QUE LA ACTUALIZACIÓN SOLAMENTE SE HAGA CADA 35 (?) CICLOS.
    for(uint8_t i=0; i<2; i++){
        posJugadores[i][0] = posJugadores[i][1];
        if (movJugadores[i]==1 && posJugadores[i][1]>P_LIMINF){
            posJugadores[i][1]--;
        }
        else if (movJugadores[i]==-1 && posJugadores[i][1]<P_LIMSUP){
            posJugadores[i][1]++;
        }
        movJugadores[i]=0;      //Reseteo las intenciones de los jugadores
    }
    for(uint8_t i=0; i<2; i++){
        for(uint8_t j=0; j<3; j++){
            if(task_validez[i*3+j]!=0){
                e_action_t accion = acciones[i][j];
                pairBool referencia = refPelotas[i][j];
                pos vieja = posPelotas[i][j].act;
                pairPos nuevaPair = (pairPos) {
                    vieja,
                    vieja,
                };
                pos nueva = vieja;

                //El valor de X se actualiza siempre de la misma manera.
                if(i==0){
                    if (referencia.x==0) nueva.x++;
                    else nueva.x--;
                }
                else{
                    if (referencia.x==0) nueva.x--;
                    else nueva.x++;
                }

                if (accion==Up){
                    if (referencia.y==0) nueva.y++;
                    else nueva.y--;
                }
                if (accion==Down){
                    if (referencia.y==0) nueva.y--;
                    else nueva.y++;
                }

                //Chequeo de límites en X.
                if (nueva.x==0){
                    //¿Chocó la paleta del jugador A?
                    if(nueva.y>=posJugadores[0][1]-3 && nueva.y<=posJugadores[0][1]+3){
                        nueva.x=1;
                        referencia.x = (referencia.x==0 ? 1 : 0);
                    }
                    //Si no chocó la paleta del jugador A, es punto para el jugador B y se destruye la tarea.
                    else{
                        task_validez[i*3+j] = 0;
                        handler_ptr[i*3+j] = 0;
                        puntajes[1]++;
                    }
                }
                else if(nueva.x==79){
                    //¿Chocó la paleta del jugador B?
                    if(nueva.y>=posJugadores[1][1]-3 && nueva.y<=posJugadores[1][1]+3){
                        nueva.x=78;
                        referencia.x = (referencia.x==0 ? 1 : 0);
                    }
                    //Si no chocó la paleta del jugador B, es punto para el jugador A y se destruye la tarea.
                    else{
                        task_validez[i*3+j] = 0;
                        handler_ptr[i*3+j] = 0;
                        puntajes[0]++;
                    }
                }

                //Chequeo de límites en Y.
                if (nueva.y==0){
                    nueva.y=1;
                    referencia.y = (referencia.y==0 ? 1 : 0);
                }
                else if (nueva.y==41){
                    nueva.y=40;
                    referencia.y = (referencia.y==0 ? 1 : 0);
                }

                //Reemplazo los valores por los actualizados.
                refPelotas[i][j] = referencia;
                nuevaPair.act = nueva;
                posPelotas[i][j] = nuevaPair;

                //Reseteo las acciones de las pelotas
                acciones[i][j]=Center;  
            }
            
        }
    }
}

void sys_talk(char* m){
    uint8_t idx = ciclo-1;
    for(uint8_t i=0; i<MSG_SIZE; i++){
        msgs[idx/3][idx%3][i] = m[i];
    }
    return;
}

uint8_t sys_setHandler(f_handler_t* f){
    //Almaceno el puntero a handler correspondiente a la pelota.
    uint8_t res;
    uint8_t idx = ciclo-1;
    if(handler_ptr[idx]==0){
        res=1;
        handler_ptr[idx] = (uint32_t)f;
        handler_TSS[idx].eip = (uint32_t)f;
    }
    else{
        res=0;
        //HAY QUE DESALOJAR LA TAREA SI SE INTENTA LLAMAR A SETHANDLER MÁS DE UNA VEZ
        desalojarTareaYHandler();
    }
    return res;
}

uint16_t sys_informAction(e_action_t action){
    uint8_t idx = ciclo-1;
    esHandler = 0;
    acciones[idx/3][idx%3] = action;
    uint16_t res = ((GDT_IDX_TSS_A1_t+2*idx)<<3) | 3;
    return res;
}

uint32_t sys_wherex(){
    uint8_t idx = ciclo-1;
    uint32_t res = posPelotas[idx/3][idx%3].act.x;
    return res;
}

uint32_t sys_wherey(){
    uint8_t idx = ciclo-1;
    uint32_t res = posPelotas[idx/3][idx%3].act.y;
    return res;
}


void crearTasks(){
    uint8_t tecla;
    uint8_t jugador;
    uint8_t tipo;
    int8_t slot;
    for(uint8_t i=0; i<2; i++){
        tecla = pelotasLanzadas[i];
        if(tecla!=0){
            jugador = i;                                                    // Las teclas 'Z','X' y 'C' son 0x2c, 0x2d y 0x2e, respectivamente, y corresponden al jugador A.
                                                                            // Las teclas 'B','N' y 'M' son 0x30, 0x31 y 0x32, respectivamente, y corresponden al jugador B.
            tipo = (jugador == 0 ? tecla - SCANCODE_Z : tecla - SCANCODE_B);
            slot = slotLibre(jugador);                                      //Si slotLibre devuelve -1, no se puede crear la tarea. Si devuelve !=-1, creamos la tarea en ese índice de task_TSS.
            if (slot>=0 && lives[jugador] != 0){
                uint8_t slotRelativo = (jugador==0 ? slot : slot-3);
                lives[jugador]--;
                tss_task_fill(slot);                                        //Se resetean los valores de la TSS en el slot correspondiente, y se la pone como válida.
                mapCopyUnmap(task_phys[slot], TASK_PHYS+2*(3*jugador+tipo)*PAG_SIZE); //Mapeo temporalmente el código de la tarea a copiar en el CR3 actual (que podría ser el de otra tarea -- no importa, porque estamos usando una dirección virtual que no colisiona con el identity mapping del kernel ni con las dos páginas del mapeo de la tarea), para copiar el código en la dirección física.
                mapCopyUnmap(task_phys[slot] + PAG_SIZE, TASK_PHYS+2*(3*jugador+tipo)*PAG_SIZE + PAG_SIZE); //Mapeo temporalmente el código de la tarea a copiar en el CR3 actual (que podría ser el de otra tarea -- no importa, porque estamos usando una dirección virtual que no colisiona con el identity mapping del kernel ni con las dos páginas del mapeo de la tarea), para copiar el código en la dirección física.
                posPelotas[jugador][slotRelativo].prev.x = (jugador==0 ? P1_TASK_INITX : P2_TASK_INITX);                //Posición inicial de la tarea
                posPelotas[jugador][slotRelativo].prev.y = posJugadores[jugador][1];                                    //Posición inicial de la tarea
                posPelotas[jugador][slotRelativo].act.x = (jugador==0 ? P1_TASK_INITX : P2_TASK_INITX);                 //Posición inicial de la tarea
                posPelotas[jugador][slotRelativo].act.y = posJugadores[jugador][1];                                     //Posición inicial de la tarea
                tipoPelotas[jugador][slotRelativo] = tipo + 1;
            }
        }
    }
    pelotasLanzadas[0]=0;                                               //Reseteamos el buffer
    pelotasLanzadas[1]=0;
}

void resetearTeclasMov(){
    movJugadores[0] = 0;
    movJugadores[1] = 0;    
}

void registrarTecla(uint8_t tecla){
    if(debugFreeze==0){
        if (tecla >= SCANCODE_Z && tecla <= SCANCODE_C){                                    //La tecla corresponde a una creación de pelota del jugador A.
            pelotasLanzadas[0] = (pelotasLanzadas[0]==0 ? tecla : pelotasLanzadas[0]);
        }
        else if (tecla >= SCANCODE_B && tecla <= SCANCODE_M){                               //La tecla corresponde a una creación de pelota jugador B.
            pelotasLanzadas[1] = (pelotasLanzadas[1]==0 ? tecla : pelotasLanzadas[1]);
        }
        else if ((tecla == SCANCODE_I)||(tecla == SCANCODE_K)){                             //La tecla es 'I' o 'K'; movimiento del jugador B.  
            movJugadores[1] = (tecla==SCANCODE_I ? 1 : -1);                                 //0x25 == 'K' ; 0X17 == 'I'
        }
        else if ((tecla == SCANCODE_W)||(tecla == SCANCODE_S)){                             //La tecla es 'W' o 'S'; movimiento del jugador A.  
            movJugadores[0] = (tecla==SCANCODE_W ? 1 : -1);                                 //0x11 == 'W' ; 0X1F == 'S'
        }
    }
    if (tecla == SCANCODE_Y){
        //DEBUG MODE: NECESITAMOS UNA VARIABLE BOOLEANA PARA SABER SI ESTAMOS EN MODO DEBUG.
        //TAMBIÈN NECESITAMOS UN BOOLEANO PARA SABER SI EL JUEGO ESTÀ FRENADO POR UNA EXCEPCIÒN.
        if(debugMode==1){
            if(debugFreeze==1){
                cleanDebug();
                debugFreeze = 0;
            }
            else{
                debugMode = 0;
                print("Debug", 0, 49, COLOR_NEGRO);

            }
        }
        else{
            debugMode = 1;
            print("Debug", 0, 49, COLOR_BLANCOYNEGRO);
        }
    }
}

void loopFin(){
    while(1){}
}