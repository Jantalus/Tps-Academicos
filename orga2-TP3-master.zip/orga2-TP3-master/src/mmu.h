/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del manejador de memoria
*/

#ifndef __MMU_H__
#define __MMU_H__

#include "stdint.h"
#include "defines.h"
#include "i386.h"
#include "tss.h"
#include "game.h"

typedef struct str_pde {
    uint8_t p:1;
    uint8_t rw:1;
    uint8_t us:1;
    uint8_t pwt:1;
    uint8_t pcd:1;
    uint8_t a:1;
    uint8_t cero:1;
    uint8_t ps:1;
    uint8_t g:1;
    uint8_t avl:3;
    uint32_t baseTable:20;
} __attribute__((__packed__, aligned (4))) pde;

typedef struct str_pte {
    uint8_t p:1;
    uint8_t rw:1;
    uint8_t us:1;
    uint8_t pwt:1;
    uint8_t pcd:1;
    uint8_t a:1;
    uint8_t d:1;
    uint8_t ps:1;
    uint8_t g:1;
    uint8_t avl:3;
    uint32_t basePage:20;
} __attribute__((__packed__, aligned (4))) pte;

pte* mmu_tableInit();

void mapCopyUnmap(uint32_t page, uint32_t task_dir);

void mmu_init();

uint32_t mmu_nextFreeKernelPage();

uint32_t mmu_nextFreeTaskPage();

void mmu_mapPage(uint32_t virtual, uint32_t cr3, uint32_t phy, uint32_t attrs);

uint32_t mmu_unmapPage(uint32_t virtual, uint32_t cr3);

uint32_t mmu_initKernelDir();

uint32_t mmu_initTaskDir(uint32_t task_dir);

#endif	/* !__MMU_H__ */