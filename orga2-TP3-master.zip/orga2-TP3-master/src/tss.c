/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de estructuras para administrar tareas
*/

#include "tss.h"

tss tss_initial = (tss) {0};				//No nos interesan los campos de este TSS: solamente tiene que estar definido para almacenar el contexto por primera y única vez cuando cambiamos a la tarea 'idle'.
tss tss_idle = (tss) {0};

int8_t slotLibre(uint8_t j){
	int8_t res = -1;
	uint8_t i;
	if (j==0){								//Jugador A
		i=0;
		while(i<3 && task_validez[i]==1) i++;
		if (i<3) res = i;
	}
	else if (j==1){
		i=3;
		while(i < 6 && task_validez[i]==1) i++;
		if (i<6) res = i;
	}
	return res;
}

void tss_task_fill(uint8_t idx){
	//Reseteamos los valores de EIP y la pila.
	task_TSS[idx].eip = (128<<20);							//EIP = 128MB
	task_TSS[idx].esp = (128<<20) + (7<<10) - 4;			//ESP = 128MB + 7 KB
	task_TSS[idx].esp0 = task_stack0ptrs[idx] + (2<<10) - 4;
	task_TSS[idx].eflags = EFLAGS_INTERRUPTENABLE;							//Reseteamos los flags para que esté activado el Interrupt Flag.
															//Teóricamente esto no es necesario, pero en la práctica las tareas modifican el valor de este flag cada vez que cambia de tarea.
	task_TSS[idx].cs = GDT_SEL_CODIGO_NIVEL3;				//Esto solamente es necesario si la tarea correspondiente a esta TSS fue desalojada por producir una excepción.
	task_TSS[idx].ss = GDT_SEL_DATOS_NIVEL3;
	task_validez[idx] = 1;
}

void resetearHandlers(){
	for(uint8_t i=0; i<6; i++){
		handler_TSS[i].cs = GDT_SEL_CODIGO_NIVEL3;
		handler_TSS[i].ss = GDT_SEL_DATOS_NIVEL3;
		handler_TSS[i].eflags = EFLAGS_INTERRUPTENABLE;
		handler_TSS[i].eip = handler_ptr[i];
		handler_TSS[i].esp = (128<<20) + (8<<10) - 4;
	}
}

void tss_init() {
	//Creamos los directorios de tablas de páginas, para cada tarea.
	uint32_t CR3[6];

	//Al principio, ninguna de las tareas existe.
	//Por lo tanto, los handlers de las tareas son todos inválidos.
	for(uint8_t i = 0; i<6; i++){
		task_validez[i] = 0;
		handler_sel[i]= ((GDT_IDX_TSS_A1_h + 2*i) << 3) | 3;
		handler_ptr[i] = 0;
	}

	//Definimos el descriptor de TSS correspondiente a la tarea 'initial'. Esta tarea en realidad no tiene ningún propósito, pero cuando hagamos
	//el task switch entre 'initial' y 'idle', el procesador va a querer almacenar el contexto actual en la TSS correspondiente a 'initial'.
	//Por eso, este descriptor de TSS no puede ser nulo.
	gdt[GDT_IDX_TSS_INITIAL] = (gdt_entry) {
		(uint16_t)    DIR_150(TSS_SIZE-1),      	/* limit[0:15]  */
        (uint16_t)    DIR_150((int)(&tss_initial)),	/* base[0:15]   */
        (uint8_t)     DIR_2316((int)(&tss_initial)),	/* base[23:16]  */
        (uint8_t)     0x09,                     	/* type         */  //Not busy (B=0)
        (uint8_t)     S_SYSTEM,                 	/* s            */
        (uint8_t)     DPL_KERNEL,               	/* dpl          */
        (uint8_t)     PRESENT_ON,               	/* p            */
        (uint8_t)     DIR_1916(TSS_SIZE-1),     	/* limit[16:19] */
        (uint8_t)     AVL_0,                    	/* avl          */
        (uint8_t)     0x0,                      	/* ---          */
        (uint8_t)     0x0,                      	/* ---          */
        (uint8_t)     GRANULARITY_BYTE,         	/* g            */
        (uint8_t)     DIR_3124((int)(&tss_initial)),	/* base[31:24]  */
	};

	//Completamos el descriptor de TSS correspondiente a la tarea idle.
	gdt[GDT_IDX_TSS_IDLE] = (gdt_entry) {
        (uint16_t)    DIR_150(TSS_SIZE-1),      	/* limit[0:15]  */
        (uint16_t)    DIR_150((int)(&tss_idle)),	/* base[0:15]   */
        (uint8_t)     DIR_2316((int)(&tss_idle)),	/* base[23:16]  */
        (uint8_t)     0x09,                     	/* type         */  //Not busy (B=0)
        (uint8_t)     S_SYSTEM,                 	/* s            */
        (uint8_t)     DPL_KERNEL,               	/* dpl          */
        (uint8_t)     PRESENT_ON,               	/* p            */
        (uint8_t)     DIR_1916(TSS_SIZE-1),     	/* limit[16:19] */
        (uint8_t)     AVL_0,                    	/* avl          */
        (uint8_t)     0x0,                      	/* ---          */
        (uint8_t)     0x0,                      	/* ---          */
        (uint8_t)     GRANULARITY_BYTE,         	/* g            */
        (uint8_t)     DIR_3124((int)(&tss_idle)),	/* base[31:24]  */
    };

    //La tarea 'idle' comparte casi todo con el kernel.
	tss_idle.cr3 = KERNEL_PAGE_DIR;
	tss_idle.eip = TASK_IDLE_PHYS;
	tss_idle.eflags = 	0x00000202;											//El único flag que seteamos es el correspondiente a 'Habilitar interrupciones'.
	tss_idle.esp = 		KERNEL_PAGE_DIR;
	tss_idle.ebp = 		0x00000000;
	tss_idle.es = 		(GDT_SEL_DATOS_NIVEL0);
	tss_idle.cs = 		(GDT_SEL_CODIGO_NIVEL0);
	tss_idle.ss = 		(GDT_SEL_DATOS_NIVEL0);
	tss_idle.ds = 		(GDT_SEL_DATOS_NIVEL0);
	tss_idle.fs = 		(GDT_SEL_DATOS_NIVEL0);
	tss_idle.gs = 		(GDT_SEL_DATOS_NIVEL0);
	tss_idle.iomap = 	0xFFFF;

	//Inicializamos las pilas de nivel cero y los directorios de tabla de página para cada tarea.
	for(int i=0;i<6;i++){
		gdt[GDT_IDX_TSS_A1_t+2*i] = (gdt_entry) {
        	(uint16_t)    DIR_150(TSS_SIZE-1),      	/* limit[0:15]  */
        	(uint16_t)    DIR_150((int)(&task_TSS[i])),	/* base[0:15]   */
        	(uint8_t)     DIR_2316((int)(&task_TSS[i])),	/* base[23:16]  */
        	(uint8_t)     0x09,                     	/* type         */  //Not busy (B=0)
        	(uint8_t)     S_SYSTEM,                 	/* s            */
        	(uint8_t)     DPL_USER,		               	/* dpl          */
        	(uint8_t)     PRESENT_ON,               	/* p            */
        	(uint8_t)     DIR_1916(TSS_SIZE-1),     	/* limit[16:19] */
        	(uint8_t)     AVL_0,                    	/* avl          */
        	(uint8_t)     0x0,                      	/* ---          */
        	(uint8_t)     0x0,                      	/* ---          */
        	(uint8_t)     GRANULARITY_BYTE,         	/* g            */
        	(uint8_t)     DIR_3124((int)(&task_TSS[i])),	/* base[31:24]  */
    	};

		task_TSS[i].iomap = 0xFFFF;
		task_TSS[i].cs = GDT_SEL_CODIGO_NIVEL3;
		task_TSS[i].ds = GDT_SEL_DATOS_NIVEL3;
		task_TSS[i].es = GDT_SEL_DATOS_NIVEL3;
		task_TSS[i].fs = GDT_SEL_DATOS_NIVEL3;
		task_TSS[i].gs = GDT_SEL_DATOS_NIVEL3;
		task_TSS[i].ss = GDT_SEL_DATOS_NIVEL3;
		task_TSS[i].esp = (128<<20) + (7<<10) - 4;
		task_TSS[i].eip = (128<<20);

		task_TSS[i].cr3 = mmu_initTaskDir(TASK_A1_PHYS+2*i*PAG_SIZE);		//Estamos copiando el código de cada tipo de tarea en cada TSS, aunque en principio podríamos copiar cualquier cosa: el orden de las TSS no indica su tipo.
		CR3[i] = task_TSS[i].cr3;

		uint32_t temp = mmu_nextFreeKernelPage();							//Pido una página de kernel para la pila de nivel 0 para cada tarea.
		task_stack0ptrs[i] = temp;

		task_TSS[i].ss0 = GDT_SEL_DATOS_NIVEL0;
		task_TSS[i].esp0 = task_stack0ptrs[i] + (2<<10) - 4;
		task_TSS[i].eflags = 0x202;
	}
	for(int i=0;i<6;i++){
		gdt[GDT_IDX_TSS_A1_t+2*i+1] = (gdt_entry) {
        	(uint16_t)    DIR_150(TSS_SIZE-1),      	/* limit[0:15]  */
        	(uint16_t)    DIR_150((int)(&handler_TSS[i])),	/* base[0:15]   */
        	(uint8_t)     DIR_2316((int)(&handler_TSS[i])),	/* base[23:16]  */
        	(uint8_t)     0x09,                     	/* type         */  //Not busy (B=0)
        	(uint8_t)     S_SYSTEM,                 	/* s            */
        	(uint8_t)     DPL_USER,               	/* dpl          */
        	(uint8_t)     PRESENT_ON,               	/* p            */
        	(uint8_t)     DIR_1916(TSS_SIZE-1),     	/* limit[16:19] */
        	(uint8_t)     AVL_0,                    	/* avl          */
        	(uint8_t)     0x0,                      	/* ---          */
        	(uint8_t)     0x0,                      	/* ---          */
        	(uint8_t)     GRANULARITY_BYTE,         	/* g            */
        	(uint8_t)     DIR_3124((int)(&handler_TSS[i])),	/* base[31:24]  */
    	};

		handler_TSS[i].iomap = 0xFFFF;
		handler_TSS[i].cs = GDT_SEL_CODIGO_NIVEL3;
		handler_TSS[i].ds = GDT_SEL_DATOS_NIVEL3;
		handler_TSS[i].es = GDT_SEL_DATOS_NIVEL3;
		handler_TSS[i].fs = GDT_SEL_DATOS_NIVEL3;
		handler_TSS[i].gs = GDT_SEL_DATOS_NIVEL3;
		handler_TSS[i].ss = GDT_SEL_DATOS_NIVEL3;
		handler_TSS[i].esp = (128<<20) + (8<<10) - 4;
		handler_TSS[i].eip = 0;
		handler_TSS[i].cr3 = CR3[i];
		handler_TSS[i].ss0 = GDT_SEL_DATOS_NIVEL0;
		handler_TSS[i].esp0 = task_stack0ptrs[i] + (4<<10) - 4;
		handler_TSS[i].eflags = 0x202;
	}
	return;
}
