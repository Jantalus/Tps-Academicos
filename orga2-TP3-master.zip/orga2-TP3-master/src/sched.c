/* ** por compatibilidad se omiten tildes **
================================================================================
 TRABAJO PRACTICO 3 - System Programming - ORGANIZACION DE COMPUTADOR II - FCEN
================================================================================
  definicion de funciones del scheduler
*/

#include "sched.h"

void sched_init() {
	ciclo = 0;
	esHandler = 0;
	return;
}

uint16_t sched_nextTask(){
	uint16_t res;						//Devuelve el selector de segmento que corresponde a la entrada en la GDT de la tarea a ejecutar.
	uint8_t final = 0;					//Vale 1 si finalizó el juego, y 0 si todavía no terminó.
	
	uint8_t cantEnJuego = 0;
	for(uint8_t i=0; i<6; i++){
		cantEnJuego+=(task_validez[i]==1 ? 1 : 0);
	}
	final = (lives[0]==0 && lives[1]==0 && cantEnJuego==0 ? 1 : 0);

	if(debugFreeze==0 && final==0){
		if (esHandler){
			uint8_t idx = ciclo-1; 			
			handler_ptr[idx]=0;		//Desalojamos el handler de la tarea anterior
			task_validez[idx]=0;	//Desalojamos la tarea anterior
			posPelotas[idx/3][idx%3].prev = posPelotas[idx/3][idx%3].act;		//Este arreglo permite borrar la pelota desalojada correctamente en la función render()
		}
										//Si cae una interrupción cuando se ejecutaba una tarea (o idle), saltamos al handler de la próxima tarea (o, en su defecto, a la tarea [o, en su defecto, a idle]).
										//Excepto si estamos en el último ciclo: en ese caso, saltamos a idle.
		if (ciclo==6){
			act();
			crearTasks();
			render();
			resetearTeclasMov();
			resetearHandlers();
			res = GDT_IDX_TSS_IDLE<<3;	
		}
		else{
			if(handler_ptr[ciclo]!=0){
				res = handler_sel[ciclo] | 3;
				esHandler = 1;
			} 
			else{
				if(task_validez[ciclo]==0){
					res = GDT_IDX_TSS_IDLE<<3;
				}
				else{
					res = ((GDT_IDX_TSS_A1_t+2*ciclo)<<3) | 3;
				}
				esHandler = 0;
	 			//Si no hay handler, nos fijamos si hay tarea: 
				//		·Si hay, saltamos directamente a la tarea, con RPL de usuario.
				//		·Si no hay tarea, saltamos a idle, con RPL de kernel.
			} 
		}
	ciclo = (ciclo+1)%7;
	}
	else if(final==1){
		renderFin();
		loopFin();
	}
	else{
		res = GDT_IDX_TSS_IDLE<<3;
	}
	return res;
}

void desalojarTareaYHandler(){
	uint8_t idx = ciclo-1;
	task_validez[idx] = 0;
	handler_ptr[idx] = 0;
	posPelotas[idx/3][idx%3].prev = posPelotas[idx/3][idx%3].act;	//Este arreglo permite borrar la pelota desalojada correctamente en la función render()
}