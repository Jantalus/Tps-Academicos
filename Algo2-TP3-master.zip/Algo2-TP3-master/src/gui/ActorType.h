#ifndef ACTOR_TYPE_H
#define ACTOR_TYPE_H

enum ActorType {
  NPC, PC
};

#endif
