
bool loadMedia(LTexture &gSpriteSheetTexture, SDL_Rect *gSpriteClips);
