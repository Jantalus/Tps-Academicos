#include "localizador.h"
#include <cassert>

Localizador::Localizador() {}

map<Jugador, PosYDir> Localizador::localizar_jugadores(const set<Jugador>&
        jugadores, const list<Fantasma>& fantasmas, const Habitacion& hab) {
    assert(false);
}
