#include "ExtremeExorcism.h"

// Completar
ExtremeExorcism::ExtremeExorcism(Habitacion h, set<Jugador> jugadores, PosYDir f_init, list<Accion> acciones_fantasma,
                                 Contexto *ctx) : _juego(h, jugadores, f_init, acciones_fantasma, ctx),
                                 _jugadores(), _habitacion(_juego.habitacion()), _fantasmas(_juego.fantasmas()){
    _jugadores = _getJugadores();
}

void ExtremeExorcism::pasar() {
    _juego.pasarTiempo();
}

void ExtremeExorcism::ejecutarAccion(Jugador j, Accion a) {
    _juego.ejecutarAccion(j, a);
}

list<pair<Jugador, PosYDir>> ExtremeExorcism::posicionJugadores() const {
    list<pair<Jugador, PosYDir>> res;
    list<PosDirJug> estados = _juego.estadoActualJugadores();
    for (PosDirJug pdj : estados) {
        PosYDir posDir = _tuplaAPosYDir(get<1>(pdj));
        res.push_back(make_pair(get<0>(pdj), posDir));
    }
    return res;
}

list<PosYDir> ExtremeExorcism::posicionFantasmas() const {
    list<tuple<Pos, Dir>> estadosFantamas = _juego.estadoActualFantasmas();
    list<PosYDir> res = _tuplasAPosYDirs(estadosFantamas);
    return res;
}

PosYDir ExtremeExorcism::posicionEspecial() const {
    tuple<Pos, Dir> ultF = _juego.estadoFantasmaEspecial();
    return _tuplaAPosYDir(ultF);
}

list<PosYDir> ExtremeExorcism::disparosFantasmas() const {
    return _tuplasAPosYDirs(_juego.estadoFantasmasDisparando());
}

set<Pos> ExtremeExorcism::posicionesDisparadas() const {
    set<Pos> res;
    linear_set<Pos> posDisparadas = _juego.ocupadasPorTirosFantasmas();
    for (Pos p : posDisparadas) {
        res.insert(p);
    }
    return set<Pos>();
}

bool ExtremeExorcism::jugadorVivo(Jugador j) const {
    return _juego.estaVivo(j);
}

const Habitacion &ExtremeExorcism::habitacion() const {
    return _habitacion;
}

PosYDir ExtremeExorcism::posicionJugador(Jugador j) const {
    PosDirJug pdj;
    for(PosDirJug p : _juego.estadoActualJugadores()){
        if(get<0>(p) == j){
            pdj = p;
            break;
        }
    }
    tuple<Pos, Dir> pd = get<1>(pdj);
        return _tuplaAPosYDir(pd);
}

const set<Jugador> &ExtremeExorcism::jugadores() const {
    return _jugadores;
}

const list<Fantasma> &ExtremeExorcism::fantasmas() const {
    return _fantasmas;
}

PosYDir ExtremeExorcism::_tuplaAPosYDir(tuple<Pos, Dir> posDir) const {
    return PosYDir(get<0>(posDir), get<1>(posDir));
}

list<PosYDir> ExtremeExorcism::_tuplasAPosYDirs(list<tuple<Pos, Dir>> posDirs) const {
    list<PosYDir> res;
    for (auto posDir : posDirs) {
        res.push_back(_tuplaAPosYDir(posDir));
    }
    return res;
}

set<Jugador> ExtremeExorcism::_getJugadores() {
    set<Jugador> res;
    list<Jugador> jugadores = _juego.jugadores();
    for (Jugador j : jugadores) {
        res.insert(j);
    }
    return res;
}
