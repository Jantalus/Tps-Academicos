#ifndef INC_2019_C1_TP3_JUEGO_H
#define INC_2019_C1_TP3_JUEGO_H

#include <modulos_basicos/string_map.h>
#include <modulos_basicos/linear_set.h>
#include <modelo/Contexto.h>
#include <modelo/Habitacion.h>
#include <modelo/TiposJuego.h>
#include <list>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

//Representacion del módulo Exorcismo Extremo
class Juego {
public:

    /* ESTE ES EL iNUEVOJUEGO DEL DISEÑO
    CON EL CONTEXTO Y LA POS INICIAL DEL FANTASMA */

    Juego(Habitacion h, set<Jugador> cj, PosYDir f_init,
          list<Accion> acciones_fantasma, Contexto *ctx) :
            _estadoJugadores(list<Nodo>()), _jugadores(string_map<Nodo *>()),
            _posDirJugadoresVivos(list<tuple<Jugador, tuple<Pos, Dir>>>()),
            _posDirFantasmasVivos(list<tuple<Pos, Dir>>()),
            _eventosPorFantasma(vector<vector<Evento>>()),
            _arrayMarcadoConDisparos(vector<vector<bool>>(h.tam(), vector<bool>(h.tam(), false))),
            _ocupadosPorDisparos(linear_set<Pos>()),
            _tablero(h),
            _turno(1),
            _historialDeRonda(vector<list<Evento>>(cj.size())) {
        _inicializarJuego(h, cj, f_init, acciones_fantasma, ctx);
    };

    void ejecutarAccion(Jugador j, Accion a);

    void pasarTiempo();

    Habitacion habitacion() const;

    list<Fantasma> fantasmas() const;

    list<tuple<Pos, Dir>> estadoActualFantasmas() const;

    tuple<Pos, Dir> estadoFantasmaEspecial() const;

    list<string> jugadores() const;

    list<Evento> acciones(Jugador jugador);

    list<PosDirJug> estadoActualJugadores() const;

    list<tuple<Pos, Dir>> estadoFantasmasDisparando() const;

    bool estaVivo(Jugador j) const;

    linear_set<Pos> ocupadasPorTirosFantasmas() const;

    bool termino() const;


private:
    struct Nodo {

        Jugador _jugador;

        bool _vivo;

        PosDirJug *_enJugVivos; // puntero al Nodo de _posDirJugadoresVivos

        unsigned int _id;

        Nodo(Jugador jug, bool vivo, PosDirJug *itPDJV, unsigned int id) :
                _jugador(jug), _vivo(vivo), _enJugVivos(itPDJV), _id(id) {};
    };

    list<PosDirJug> _posDirJugadoresVivos;

    list<tuple<Pos, Dir>> _posDirFantasmasVivos;

    list<Nodo> _estadoJugadores;

    // Hicimos esto, ya que nos topamos con que realmente
    // es un lio implementar el "desenlazar"
    list<Nodo *> _jugadoresVivos;

    list<tuple<unsigned int, tuple<Pos, Dir> * >> _fantasmasVivos;

    vector<vector<vector<unsigned int>>> _matrizDeAlcance;

    vector<vector<bool>> _arrayMarcadoConDisparos;

    vector<list<Evento>> _historialDeRonda;

    vector<vector<Evento>> _eventosPorFantasma;

    linear_set<Pos> _ocupadosPorDisparos;

    string_map<Nodo *> _jugadores;

    Habitacion _tablero;

    unsigned int _turno;


    Contexto *_ctx;


    Dir _conseguirDireccion(tuple<Pos, Dir> pd, Accion a);

    Pos _modificarPos(Pos p, Accion a);

    list<Evento> _armarEventos(list<Accion> la, tuple<Pos, Dir> pi);

    vector<vector<vector<unsigned int>>> _armarMatrizDeAlcance(Habitacion h);

    vector<unsigned int> _alcanceEnDirecciones(Habitacion h, int i, int j);

    void _inicializarJuego(Habitacion &h, set<Jugador> &cj, PosYDir &f_init,
                           list<Accion> &acciones_fantasma, Contexto *ctx);

    void _jugadoresEsperan();

    void _mover(PosDirJug *enJugVivos, Accion a);

    void _ejecutarAccionesFantasmas();

    void _disparoJugador(tuple<Pos, Dir> posDir);

    void _nuevaRonda(list<Evento> f);

    bool _libre(unsigned int x, unsigned int y);

    void _marcarDisparo(unsigned int x, unsigned int y);

    void _agregarEsperarEInvertidos(list<Evento> &f);

    Evento _invertirEvento(Evento e);


};


#endif //INC_2019_C1_TP3_JUEGO_H
