#include "Juego.h"

void Juego::ejecutarAccion(Jugador j, Accion a) {
    Nodo nodoJug = *_jugadores[j];// Nodo del jugador en el diccTrie, esta privado en juego
    if (a != DISPARAR) { //accion no es disparo
        _mover(nodoJug._enJugVivos, a);

        tuple<Pos, Dir> posDir = get<1>(*nodoJug._enJugVivos); // agregamos la accion al historial, FALTABA
        Evento evento = Evento(get<0>(posDir), get<1>(posDir), false);
        _historialDeRonda[nodoJug._id].push_back(evento);

        _jugadoresEsperan();

        _ejecutarAccionesFantasmas();

        _turno++;
    } else {
        tuple<Pos, Dir> posDirJug = get<1>(*nodoJug._enJugVivos); // tupla de posDir en el nodo
        _disparoJugador(posDirJug); // ejecutar disparo jugador

        if (termino()) {
            tuple<Pos, Dir> posDir = get<1>(*nodoJug._enJugVivos);// agregamos la accion al historial, FALTABA
            Evento evento = Evento(get<0>(posDir), get<1>(posDir), true);
            _historialDeRonda[nodoJug._id].push_back(evento);

            _nuevaRonda(_historialDeRonda[nodoJug._id]);
        } else {
            _ejecutarAccionesFantasmas();
            _turno++;
        }
    }

}

void Juego::pasarTiempo() {
    _jugadoresEsperan();
    _ejecutarAccionesFantasmas();
    _turno++;
}

Habitacion Juego::habitacion() const {
    return _tablero;
}

list<Fantasma> Juego::fantasmas() const {
    list<Fantasma> res;
    for (vector<Evento> vFantasma : _eventosPorFantasma) {
        Fantasma f;
        for (int i = 0; i < (vFantasma.size() - 10) / 2; i++) {
            f.push_back(vFantasma[i]);
        }
        res.push_back(f);
    }
    return res;
}

list<tuple<Pos, Dir>> Juego::estadoActualFantasmas() const {
    return _posDirFantasmasVivos;
}

tuple<Pos, Dir> Juego::estadoFantasmaEspecial() const {
    return _posDirFantasmasVivos.back();
}

list<string> Juego::jugadores() const {
    return _jugadores.keys();
}

list<Evento> Juego::acciones(Jugador jugador) {
    Nodo *estadoJugador = _jugadores.at(jugador);
    return _historialDeRonda[estadoJugador->_id];
}

list<PosDirJug> Juego::estadoActualJugadores() const {
    return _posDirJugadoresVivos;
}

list<tuple<Pos, Dir>> Juego::estadoFantasmasDisparando() const {
    list<tuple<Pos, Dir>> res;
    for (auto fantasma : _fantasmasVivos) {
        if (((Evento) _eventosPorFantasma[get<0>(fantasma)][(_turno - 1) % _eventosPorFantasma[get<0>(fantasma)].size()]).dispara) {
            res.push_back(*get<1>(fantasma));
        }
    }
    return res;
}

bool Juego::estaVivo(Jugador j) const {
    Nodo *estadoJugador = _jugadores.at(j);
    return estadoJugador->_vivo;
}

linear_set<Pos> Juego::ocupadasPorTirosFantasmas() const {
    return _ocupadosPorDisparos;
}

bool Juego::termino() const {
    if (_fantasmasVivos.empty()) {
        return true;
    }
    unsigned int numeroDelUltimoFantasma = get<0>(_fantasmasVivos.back());
    return numeroDelUltimoFantasma != _eventosPorFantasma.size() - 1; // Los fantasmas se numeran desde el 0
}

list<Evento> Juego::_armarEventos(list<Accion> la, tuple<Pos, Dir> pi) {
    list<Evento> res;
    if(!la.empty()) {
        res.push_back(Evento(get<0>(pi), get<1>(pi), false));
        while (!la.empty()) {
            Accion nuevaAccion = la.front();
            res.push_back(Evento(_modificarPos(res.back().pos, nuevaAccion),
                                 _conseguirDireccion(make_tuple(res.back().pos, res.back().dir), nuevaAccion),
                                 nuevaAccion == DISPARAR));
            la.pop_front();
        }
        // agregar esperar e invertidos
        _agregarEsperarEInvertidos(res);
    } else {
        res.push_back(Evento(get<0>(pi), get<1>(pi), false));
        // agregar esperar e invertidos
        _agregarEsperarEInvertidos(res);

    }
    return res;
}

Pos Juego::_modificarPos(Pos p, Accion a) {
    //TODO: Esto creo que hay que invertilor por lo que hablo en el metodo accionesFantasmas
    //CREO QUE AHI QUEDO LO DE INVERTIRLO, DEJO LO VIEJO POR LAS DUDAS
    if (a == MARRIBA) {
        if (_libre(p.first , p.second+ 1)) {

            p.second = p.second + 1;
        }

    } else if (a == MDERECHA) {
        if (_libre(p.first + 1, p.second)) {
            p.first = p.first + 1;
        }

    } else if (a == MABAJO) {
        if (_libre(p.first , p.second- 1)) {
            p.second = p.second - 1;
        }

    } else if (a == MIZQUIERDA) {
        if (_libre(p.first - 1, p.second)) {

            p.first = p.first - 1;
        }

    }
        /*switch (a) {
            case MARRIBA:
                get<0>(p) = p.first + 1;

            case MABAJO:
                get<0>(p) = p.first - 1;

            case MIZQUIERDA :
                get<1>(p) = p.first - 1;

            case MDERECHA :
                get<1>(p) = p.first + 1;

            default: {
            } //Lo dejamos en el lugar
        }*/
        return p;

}
Dir Juego::_conseguirDireccion(tuple<Pos, Dir> pd, Accion a) {
    switch (a) {
        case MARRIBA:
            return ARRIBA;

        case MABAJO:
            return ABAJO;

        case MIZQUIERDA :
            return IZQUIERDA;

        case MDERECHA :
            return DERECHA;

        default:
            return get<1>(pd);
    }
}


vector<unsigned int> Juego::_alcanceEnDirecciones(Habitacion h, int i, int j) {
    vector<unsigned int> res(4, 0);
    int i2 = i;
    int j2 = j + 1;
    int contador = 0;
    while (j2 < h.tam() and !h.ocupado(make_pair(i2, j2))) {
        contador++;
        j2++;
    }
    res[ARRIBA] = contador;
    contador = 0;
    j2 = j - 1;
    while (j2 >= 0 and !h.ocupado(make_pair(i2, j2))) {
        contador++;
        j2--;
    }
    res[ABAJO] = contador;
    contador = 0;
    j2 = j;
    i2 = i + 1;
    while (i2 < h.tam() and !h.ocupado(make_pair(i2, j2))) {
        contador++;
        i2++;
    }
    res[DERECHA] = contador;
    contador = 0;
    i2 = i - 1;
    while (i2 >= 0 and !h.ocupado(make_pair(i2, j2))) {
        contador++;
        i2--;
    }
    res[IZQUIERDA] = contador;
    return res;
}


vector<vector<vector<unsigned int>>> Juego::_armarMatrizDeAlcance(Habitacion h) {
    // La matriz de mxm con el rango de cada una de las 4 direcciones
    vector<vector<vector<unsigned int>>> res(h.tam(), vector<vector<unsigned int>>(h.tam(), vector<unsigned int>(4)));
    for (int i = 0; i < h.tam(); i++) {
        for (int j = 0; j < h.tam(); j++) {
            res[i][j] = _alcanceEnDirecciones(h, i, j);
        }
    }
    return res;
}

void Juego::_inicializarJuego(Habitacion &h, set<Jugador> &cj, PosYDir &f_init,
                              list<Accion> &acciones_fantasma, Contexto *ctx) {

    Fantasma fantasma = _armarEventos(acciones_fantasma, make_tuple(f_init.pos, f_init.dir));
    vector<Evento> eventosIniciales(fantasma.begin(), fantasma.end());
    _eventosPorFantasma.push_back(eventosIniciales);

    tuple<Pos, Dir> posFantasmaInicial = make_tuple(eventosIniciales[0].pos, eventosIniciales[0].dir);
    _posDirFantasmasVivos.push_back(posFantasmaInicial);
    tuple<Pos, Dir> *j = &_posDirFantasmasVivos.back();
    _fantasmasVivos.push_back(make_tuple(0, j));

    list<Fantasma> fs = list<Fantasma>();
    fs.push_back(fantasma);

    map<Jugador, PosYDir> posIniciales = ctx->localizar_jugadores(cj, fs, h);
    int i = 0;

    for (auto posDirJug : posIniciales) {

        Jugador jugador = posDirJug.first;
        PosYDir posYDir = posDirJug.second;

        _posDirJugadoresVivos.push_back(make_tuple(jugador, make_tuple(posYDir.pos, posYDir.dir)));

        PosDirJug *itPDJV = &(_posDirJugadoresVivos.back());

        _estadoJugadores.push_back(Nodo(jugador, true, itPDJV, i));

        _jugadores[jugador] = &(_estadoJugadores.back());

        _jugadoresVivos.push_back(&(_estadoJugadores.back())); // Inicializamos con los punteros a los jugadores

        i++;
    }

    for (Nodo n : _estadoJugadores) {
        _historialDeRonda[n._id].push_back(
                Evento(get<0>(get<1>(*n._enJugVivos)), get<1>(get<1>(*n._enJugVivos)), false));
    }

    _matrizDeAlcance = _armarMatrizDeAlcance(h);


    _ctx = ctx;
}

void Juego::_jugadoresEsperan() {
    for (Nodo *estadoJugador : _jugadoresVivos) {
        list<Evento>* accionesJug = &_historialDeRonda[estadoJugador->_id];
        if ((*accionesJug).size() == _turno) {
            //No realizo accion en este turno
            //Le ponemos la misma pos anterior y sin disparo
            Evento espera = (*accionesJug).back();
            espera.dispara = false;
            (*accionesJug).push_back(espera);
        }
    }
}

void Juego::_mover(PosDirJug *enJugVivos, Accion a) {
    Pos t = get<0>(get<1>(*enJugVivos));

    //TODO: Esto creo que hay que invertilor por lo que hablo en el metodo accionesFantasmas

    if (a == MDERECHA) {
        if (_libre(t.first + 1, t.second)) {
            get<0>(get<1>(*enJugVivos)).first = t.first + 1;
            get<1>(get<1>(*enJugVivos)) = DERECHA;
        } else {
            get<1>(get<1>(*enJugVivos)) = DERECHA;
        }

    } else if (a == MARRIBA) {
        if (_libre(t.first, t.second + 1)) {
            get<0>(get<1>(*enJugVivos)).second = t.second + 1;
            get<1>(get<1>(*enJugVivos)) = ARRIBA;
        } else {
            get<1>(get<1>(*enJugVivos)) = ARRIBA;
        }

    } else if (a == MIZQUIERDA) {
        if (_libre(t.first - 1, t.second)) {
            get<0>(get<1>(*enJugVivos)).first = t.first - 1;
            get<1>(get<1>(*enJugVivos)) = IZQUIERDA;
        } else{
            get<1>(get<1>(*enJugVivos)) = IZQUIERDA;
        }

    } else if (a == MABAJO) {
        if (_libre(t.first, t.second - 1)) {
            get<0>(get<1>(*enJugVivos)).second = t.second - 1;
            get<1>(get<1>(*enJugVivos)) = ABAJO;
        } else {
            get<1>(get<1>(*enJugVivos)) = ABAJO;
        }

    }
}

void Juego::_ejecutarAccionesFantasmas() {
    for (tuple<unsigned int, tuple<Pos, Dir> *> f : _fantasmasVivos) {

        tuple<Pos, Dir> posDir = *(get<1>(f));
        Evento eventoActual = _eventosPorFantasma[get<0>(f)][_turno % (_eventosPorFantasma[get<0>(f)].size())];
        posDir = make_tuple(eventoActual.pos, eventoActual.dir);
        *get<1>(f) = posDir;

        if (eventoActual.dispara) {

            //TODO: IMPORTANTE LEER
            //En el diseño usamos el el arrayMarcadoConDisparos como si fuese [x][y]
            //Pero usamos Pos como si fuese [y][x] es medio raro.

            int y = ((Pos) (get<0>(posDir))).second;
            int x = ((Pos) (get<0>(posDir))).first;
            y = _tablero.tam() - y - 1;

            //Marcamos los disparos
            switch (eventoActual.dir) {
                case ARRIBA: {
                    //En el diseño aca sumamos 1, pero ir para arriba es restar 1
                    y = y - 1; //Primera posicion a modificar
                    while (y >= 0 and y < _tablero.tam() and _libre(y, x)) {
                        _marcarDisparo(x, y);
                        y--;
                    }
                    break;
                }
                case IZQUIERDA: {
                    x = x - 1; //Primera posicion a modificar
                    while (x >= 0 and x < _tablero.tam() and _libre(y, x)) {
                        _marcarDisparo(x, y);
                        x--;
                    }
                    break;
                }
                case DERECHA: {
                    x = x + 1; //Primera posicion a modificar
                    while (x < _tablero.tam() and _libre(y, x)) {
                        _marcarDisparo(x, y);
                        x++;
                    }
                    break;
                }
                case ABAJO: {
                    y = y + 1; //Primera posicion a modificar
                    while (y < _tablero.tam() and _libre(y, x)) {
                        _marcarDisparo(x, y);
                        y++;
                    }
                    break;
                }
                default:
                    break;
            }

            //Checkeamos si algun jugador murio
            auto it = _jugadoresVivos.begin();
            while (it != _jugadoresVivos.end() and _jugadoresVivos.size() > 0) {
                //Obtengo la pos del jugador
                Pos posJug = get<0>(get<1>(*(*it)->_enJugVivos));
                int fila = _tablero.tam() - posJug.second - 1;
                if (_arrayMarcadoConDisparos[fila][posJug.first]) {
                    (*it)->_vivo = false;
                    _posDirJugadoresVivos.remove(*((*it)->_enJugVivos));
                    it = _jugadoresVivos.erase(it);
                }
                else {
                    it++;
                }
            }
        } else { // agrego actualizar posDirFantasmasVivos
                Evento eventoActual = _eventosPorFantasma[get<0>(f)][_turno % (_eventosPorFantasma[get<0>(f)].size())];
                posDir = make_tuple(eventoActual.pos, eventoActual.dir);
                *get<1>(f) = posDir;
            }
        }
    }


void Juego::_disparoJugador(tuple<Pos, Dir> posDir) {
    unsigned int y = ((Pos) get<0>(posDir)).second;
    unsigned int x = ((Pos) get<0>(posDir)).first;

    unsigned int disparoMaximo = _matrizDeAlcance[x][y][get<1>(posDir)]; // esta armada "al revez"

    auto fantasmaActual = _fantasmasVivos.begin();
    while (fantasmaActual != _fantasmasVivos.end()) {
        unsigned int yFan = ((Pos) get<0>((*(get<1>(*fantasmaActual))))).second;
        unsigned int xFan = ((Pos) get<0>((*(get<1>(*fantasmaActual))))).first;

        switch (get<1>(posDir)) {
            case ARRIBA:
                //Me fijo si esta en la columna
                if (xFan == x) {
                    //Si lo están, me fijo si la pos del fantasma esta en el rango del disparo
                    //TODO: Esta logica esta bien? Es lo que esta en el diseño
                    if (y + disparoMaximo >= yFan  && yFan > y) {
                        _posDirFantasmasVivos.remove(*get<1>(*fantasmaActual));
                        fantasmaActual = _fantasmasVivos.erase(fantasmaActual);
                    } else {fantasmaActual++;}
                } else {fantasmaActual++;}
                break;
            case ABAJO:
                //Me fijo si esta en la columna
                if (xFan == x) {
                    if (y - disparoMaximo <= yFan && yFan < y) {
                        _posDirFantasmasVivos.remove(*get<1>(*fantasmaActual));
                        fantasmaActual = _fantasmasVivos.erase(fantasmaActual);
                    } else {fantasmaActual++;}
                } else {fantasmaActual++;}
                break;
            case IZQUIERDA:
                //Me fijo si esta en la fila
                if (yFan == y) {
                    if (x - disparoMaximo <= xFan && xFan < x) {
                        _posDirFantasmasVivos.remove(*get<1>(*fantasmaActual));
                        fantasmaActual = _fantasmasVivos.erase(fantasmaActual);
                    } else {fantasmaActual++;}
                } else {fantasmaActual++;}
                break;
            case DERECHA:
                //Me fijo si esta en la fila
                if (yFan == y) {
                    if (x + disparoMaximo >= xFan && xFan > x) {
                        _posDirFantasmasVivos.remove(*get<1>(*fantasmaActual));
                        fantasmaActual = _fantasmasVivos.erase(fantasmaActual);
                    } else {fantasmaActual++;}
                } else {fantasmaActual++;}
                break;
        }
       //fantasmaActual++; PERDON GABO
    }
}

void Juego::_nuevaRonda(list<Evento> f) {
    for (int i = 0; i < _tablero.tam(); i++) {
        for (int j = 0; j < _tablero.tam(); j++) {
            _arrayMarcadoConDisparos[i][j] = false;
        }
    }

    _ocupadosPorDisparos = linear_set<Pos>();
    _turno = 1;

    list<Fantasma> fs = list<Fantasma>();   //me creo una lista con los fantasmas
    for (int i = 0; i < _eventosPorFantasma.size(); i++) {
        list<Evento> fantasma = list<Evento>();
        for (int j = 0; j < (_eventosPorFantasma[i].size() -10)/2; j++) {
            fantasma.push_back(_eventosPorFantasma[i][j]);
        }
        fs.push_back(fantasma);
    }
    fs.push_back(f);

    set<Jugador> conjJug = set<Jugador>();
    for(Jugador j : _jugadores.keys()){
        conjJug.insert(j);
    }
    
    map<Jugador, PosYDir> posIniciales = _ctx->localizar_jugadores(conjJug, fs, _tablero);

    _jugadoresVivos = list<Nodo *>();

    _posDirJugadoresVivos = list<PosDirJug>();

    _historialDeRonda = vector<list<Evento>>(_jugadores.keys().size());

    for (Nodo &n : _estadoJugadores) {
        n._vivo = true;

        _jugadoresVivos.push_back(&n);

        PosDirJug nueva = make_tuple(n._jugador,
                                     make_tuple(posIniciales.at(n._jugador).pos, posIniciales.at(n._jugador).dir));
        _posDirJugadoresVivos.push_back(nueva);

        n._enJugVivos = &(_posDirJugadoresVivos.back());

        //historial nuevo
        _historialDeRonda[n._id].push_back(
                Evento(get<0>(get<1>(*n._enJugVivos)), get<1>(get<1>(*n._enJugVivos)), false));
    }

    _posDirFantasmasVivos = list<tuple<Pos, Dir>>();

    _agregarEsperarEInvertidos(f);
    vector<Evento> fVector;
    for (Evento e : f) {
        fVector.push_back(e);
    }
    _eventosPorFantasma.push_back(fVector);
    for (int j = 0; j < _eventosPorFantasma.size(); j++) {
        Pos pos = (_eventosPorFantasma[j][0].pos);
        Dir dir = (_eventosPorFantasma[j][0].dir);
        _posDirFantasmasVivos.push_back(make_tuple(pos, dir));
        _fantasmasVivos.push_back(make_tuple(j, (&_posDirFantasmasVivos.back())));
    }
}

void Juego::_marcarDisparo(unsigned int x, unsigned int y) {
    if (!_arrayMarcadoConDisparos[y][x]) {
        _ocupadosPorDisparos.fast_insert(make_pair(x, y));
        _arrayMarcadoConDisparos[y][x] = true;
    }
}

bool Juego::_libre(unsigned int x, unsigned int y) {
    pair<int, int> p;
    p.first = x;
    p.second = y;
    return !_tablero.ocupado(p);
}

void Juego::_agregarEsperarEInvertidos(list<Evento> &f) {

    list<Evento> eventosInvertidos = list<Evento> ();
    for(Evento e : f){
        eventosInvertidos.push_back(_invertirEvento(e));
    }

    eventosInvertidos.reverse();

    Evento ultEvento = f.back();
    for(int i = 0; i < 5; i++) {
        f.push_back(Evento(ultEvento.pos, ultEvento.dir, false));
    }

    for(Evento e : eventosInvertidos){
        f.push_back(e);
    }

    ultEvento = f.back();
    for(int i = 0; i < 5; i++) {
        f.push_back(Evento(ultEvento.pos, ultEvento.dir, false));
    }

}

Evento Juego::_invertirEvento(Evento e) {
    Pos p = e.pos;
    Dir d = e.dir;
    bool b = e.dispara;
    switch(d){
        case ARRIBA :{
            d = ABAJO;
            break;
        }
        case ABAJO: {
            d = ARRIBA;
            break;
        }
        case IZQUIERDA:{
            d = DERECHA;
            break;
        }
        case DERECHA:{
            d = IZQUIERDA;
            break;
        }
    }
    return Evento(p, d, b);
}

