#include "Habitacion.h"
#include "assert.h"
#include <istream>
#include <sstream>
#include <string>

Habitacion string_to_hab(std::istream &is) {
    int row = 0;
    int col = 0;
    int max_col = 0;
    int width;
    int height;

    set<Pos> occupied;

    char c;
    while (is.get(c)) {
        if (c == '#') {
            occupied.insert(Pos(col, row));
            col++;
        } else if (c == '\n') {
            row++;
            max_col = std::max(col, max_col);
            col = 0;
        } else {
            col++;
        }
    }
    width = max_col;
    height = row;

    assert(height == width);

    return Habitacion(height, occupied);
}

Habitacion string_to_hab(string s) {
    std::istringstream is(s);
    int row = 0;
    int col = 0;
    int max_col = 0;
    int width;
    int height;

    set<Pos> occupied;

    char c;
    while (is.get(c)) {
        if (c == '#') {
            occupied.insert(Pos(col, row));
            col++;
        } else if (c == '\n') {
            row++;
            max_col = std::max(col, max_col);
            col = 0;
        } else {
            col++;
        }
    }
    width = max_col;
    height = row;

    assert(height == width);

    return Habitacion(height, occupied);
}

Habitacion::Habitacion(unsigned int tam, set<Pos> ocupadas) {
    _size = tam;

    _build(ocupadas);
}

unsigned int Habitacion::tam() const {
    return _size;
}

bool Habitacion::ocupado(Pos pos) const { //puse un or entre los rangos y el ocupado
    return !(pos.first >= 0 && pos.first < tam() &&
           pos.second >= 0 && pos.second < tam())
           || (_board[_size-1-pos.second][pos.first]);
}

bool Habitacion::operator==(const Habitacion &hab) const {
    return _size == hab._size && _board == hab._board;
}

void Habitacion::_build(set<Pos> occupied_pos) {
    _board = vector<vector<bool>>(_size, vector<bool>(_size, false));
    for (Pos pos : occupied_pos) {
        occupy(pos);
    }
}

unsigned int Habitacion::_getYFromPos(Pos pos) {
    //Como el tablero arranca con (0,0) abajo a la izquierda
    //Corremos el eje y le restamos la pos y original
    return _size - 1 - pos.second;
}

void Habitacion::occupy(Pos pos) {
    _board[_getYFromPos(pos)][pos.first] = true;
}
